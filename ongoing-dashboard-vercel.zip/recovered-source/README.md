# Ongoing Operations Dashboard

Vercel-ready source recovered from the published Ongoing dashboard.

## Upload to Vercel

1. In Vercel, choose **Add New → Project**.
2. Click **folder** under “You can also drag and drop your project”.
3. Select this entire `recovered-source` folder.
4. Vercel should detect **Vite** automatically.
5. Use Build Command `npm run build` and Output Directory `dist`.
6. Click **Deploy**.

## Local commands

```bash
npm install
npm run dev
npm run build
```

## Data behavior

This standalone version uses the snapshot data bundled with the original deployment, so it renders without Aime authentication. Live Feishu/Aeolus editing and refresh are disabled outside Aime. To update data later, replace:

- `src/data/ongoingSnapshot.json`
- `src/data/pofdChecking.json`
