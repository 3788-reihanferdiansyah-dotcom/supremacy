import { IconIllustrationCancel } from "@arco-design/iconbox-react-rdsvc";

export function AccessDeniedPage({ owner }: { owner: string }) {
  return (
    <div className="sso-access-denied" role="alert" data-aime-component-name="div"  data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx"  data-aime-column="5"  data-aime-line="5"  data-insp-path="src/infra/sso/AccessDeniedPage.tsx:5:5:div" >
      <div className="sso-access-denied-content" data-aime-component-name="div"  data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx"  data-aime-column="7"  data-aime-line="6"  data-insp-path="src/infra/sso/AccessDeniedPage.tsx:6:7:div" >
        <div className="sso-access-denied-icon" data-aime-component-name="div"  data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx"  data-aime-column="9"  data-aime-line="7"  data-insp-path="src/infra/sso/AccessDeniedPage.tsx:7:9:div" >
          <IconIllustrationCancel  data-aime-component-name="IconIllustrationCancel" data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx" data-aime-column="11" data-aime-line="8" data-insp-path="src/infra/sso/AccessDeniedPage.tsx:8:11:IconIllustrationCancel"/>
        </div>
        <div className="sso-access-denied-title" data-aime-component-name="div"  data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx"  data-aime-column="9"  data-aime-line="10"  data-insp-path="src/infra/sso/AccessDeniedPage.tsx:10:9:div" >您没有权限访问该页面</div>
        <div className="sso-access-denied-copy" data-aime-component-name="div"  data-aime-path-name="src/infra/sso/AccessDeniedPage.tsx"  data-aime-column="9"  data-aime-line="11"  data-insp-path="src/infra/sso/AccessDeniedPage.tsx:11:9:div" >
          请联系网页作者 {owner} 申请权限
        </div>
      </div>
    </div>
  );
}
