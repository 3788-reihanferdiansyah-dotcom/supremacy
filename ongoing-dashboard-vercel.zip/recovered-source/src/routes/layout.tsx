/**
 * AuthProvider 是 SSO 相关的页面基建，不要删掉。
 * 业务代码写在 Outlet 里面（即各 page.tsx 中）。
 */
import { Outlet } from '@edenx/runtime/router';
import { AuthProvider } from '@/infra/sso/AuthProvider';
import '@/infra/sso/sso.css';
import './index.css';

export default function Layout() {
  return (
    <AuthProvider data-aime-component-name="AuthProvider" data-aime-path-name="src/routes/layout.tsx" data-aime-column="5" data-aime-line="12" data-insp-path="src/routes/layout.tsx:12:5:AuthProvider">
      <Outlet  data-aime-component-name="Outlet" data-aime-path-name="src/routes/layout.tsx" data-aime-column="7" data-aime-line="13" data-insp-path="src/routes/layout.tsx:13:7:Outlet"/>
    </AuthProvider>
  );
}
