import ongoingCourierLogo from '@/assets/ongoing-courier-logo.png';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import snapshotData from '@/data/ongoingSnapshot.json';
import pofdCheckingData from '@/data/pofdChecking.json';
import {
  Activity,
  AlertTriangle,
  Building2,
  CheckCircle2,
  Clock3,
  LayoutDashboard,
  ListChecks,
  PackageCheck,
  TrendingUp,
  Truck,
} from 'lucide-react';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

type DriverRow = {
  section: string;
  driver: string;
  cycle1: number;
  sd12: number;
  pct12: number | null;
  cycle2: number;
  pickup: number;
  failed: number;
  ofd: number;
  sdOverall: number;
  pctOverall: number | null;
  rowOrder: number;
};

type PofdRow = {
  entryKey: string;
  date: string;
  awb: string;
  driverName: string;
  cancellationReason: string;
  shipmentStatus: string;
  result: PofdResultValue;
  reason: string;
  inputBy: string;
};

type PofdResultValue = '' | 'valid' | 'invalid';

type PofdReviewState = {
  result: PofdResultValue;
  reason: string;
  inputBy: string;
};

type PofdSheetReview = PofdReviewState & {
  rowIndex: number;
};

type PofdFilterState = {
  date: string;
  awb: string;
  driverName: string;
  cancellationReason: string;
  result: 'all' | 'blank' | PofdResultValue;
  reason: 'all' | 'blank' | string;
};

type DeliveryTier = 'FAR_FROM_DONE' | 'DECENT' | 'ALL_NICE' | 'FINISHED';
type DeliveryStatus = 'ALL' | DeliveryTier;
type PickupView = 'cycle1' | 'cycle2' | 'pickup';
type DriverDetailTab = 'performance' | 'pofd-checking';

const SECTION_TITLES = [
  'PONDOK KOPI',
  'PONDOK KELAPA',
  'PONDOK BAMBU & DUREN SAWIT',
  'KLENDER',
  'DEDICATED',
] as const;

const DASHBOARD_SECTIONS = ['ALL SECTIONS', ...SECTION_TITLES] as const;

const SOURCE_URL =
  'https://bytedance.larkoffice.com/wiki/LGLiwHdociQnRRkW0kvcwakhn1d?renamingWikiNode=false&sheet=PDeCYf';
const REASON_FTD_RANGE = 'A1:G5000';
const POFD_EMPTY_RESULT = '__blank__';
const POFD_ALL_FILTER = '__all__';
const POFD_EMPTY_REASON = '__blank_reason__';
const POFD_RESULT_OPTIONS: {
  value: PofdResultValue | typeof POFD_EMPTY_RESULT;
  label: string;
}[] = [
  { value: POFD_EMPTY_RESULT, label: 'Blank' },
  { value: 'valid', label: 'Valid' },
  { value: 'invalid', label: 'Invalid' },
];

const PICKUP_VIEWS: {
  key: PickupView;
  label: string;
  tableLabel: string;
}[] = [
  {
    key: 'cycle1',
    label: 'Pick-up Cycle 1',
    tableLabel: 'Pick-up Cycle 1',
  },
  {
    key: 'cycle2',
    label: 'Pick-up Cycle 2',
    tableLabel: 'Pick-up Cycle 2',
  },
  {
    key: 'pickup',
    label: 'Pick-up Overall',
    tableLabel: 'Pick-up Overall',
  },
];

const DELIVERY_STATUSES: {
  key: DeliveryStatus;
  label: string;
  activeClass: string;
}[] = [
  {
    key: 'ALL',
    label: 'All Overall Status',
    activeClass: 'h-8 bg-red-700 px-3 text-xs text-white hover:bg-red-800',
  },
  {
    key: 'FAR_FROM_DONE',
    label: 'Far from done',
    activeClass: 'bg-red-900 text-white hover:bg-red-950',
  },
  {
    key: 'DECENT',
    label: 'Decent',
    activeClass: 'bg-amber-600 text-white hover:bg-amber-700',
  },
  {
    key: 'ALL_NICE',
    label: 'All Nice',
    activeClass: 'bg-emerald-700 text-white hover:bg-emerald-800',
  },
  {
    key: 'FINISHED',
    label: 'Finished!',
    activeClass: 'bg-emerald-500 text-white hover:bg-emerald-600',
  },
];

const TIER_BADGE_CLASS: Record<DeliveryTier, string> = {
  FAR_FROM_DONE: 'bg-red-900 font-black text-white',
  DECENT: 'bg-amber-600 font-black text-white',
  ALL_NICE: 'bg-emerald-700 font-black text-white',
  FINISHED: 'bg-emerald-500 font-black text-white',
};

const TIER_LABEL: Record<DeliveryTier, string> = {
  FAR_FROM_DONE: 'Far from done',
  DECENT: 'Decent',
  ALL_NICE: 'All Nice',
  FINISHED: 'Finished!',
};

if (typeof window !== 'undefined') {
  (
    window as unknown as { __AEOLUS_FEISHU_SEND_BINDING__?: boolean }
  ).__AEOLUS_FEISHU_SEND_BINDING__ = true;
}

const manifest = {
  name: 'Ongoing Operations Dashboard',
  version: '0.0.1',
  needAuth: true,
  region: 'CN',
  feishuResourceBindings: [
    {
      bindingId: 'ongoingSheet',
      resourceType: 'sheetRange',
      spreadsheetToken: 'BMKDsLs6hhTyh9t0s1yls5Fvg9d',
      sheetId: 'PDeCYf',
    },
    {
      bindingId: 'rawDataSheet',
      resourceType: 'sheetRange',
      spreadsheetToken: 'BMKDsLs6hhTyh9t0s1yls5Fvg9d',
      sheetId: '3f6bb6',
    },
    {
      bindingId: 'reasonFtdSheet',
      resourceType: 'sheetRange',
      spreadsheetToken: 'BMKDsLs6hhTyh9t0s1yls5Fvg9d',
      sheetId: 'yLdn5S',
    },
  ],
};

function validPercentage(value: number | null): value is number {
  return value !== null && Number.isFinite(value) && value >= 0 && value <= 1;
}

function pct(value: number | null) {
  return value === null ? '-' : `${(value * 100).toFixed(1)}%`;
}

function getDeliveryTier(percentage: number): DeliveryTier {
  // Updated business logic:
  // - Finished! = only 100.0%
  // - All Nice = 90.0% to 99.9%
  // - Decent = 70.0% to 89.9%
  // - Far from done = below 70.0%
  if (percentage >= 1) return 'FINISHED';
  if (percentage >= 0.9) return 'ALL_NICE';
  if (percentage >= 0.7) return 'DECENT';
  return 'FAR_FROM_DONE';
}

if (
  getDeliveryTier(0.699999) !== 'FAR_FROM_DONE' ||
  getDeliveryTier(0.7) !== 'DECENT' ||
  getDeliveryTier(0.899999) !== 'DECENT' ||
  getDeliveryTier(0.9) !== 'ALL_NICE' ||
  getDeliveryTier(0.9999) !== 'ALL_NICE' ||
  getDeliveryTier(1) !== 'FINISHED'
) {
  throw new Error('Delivery status percentage boundaries are invalid');
}

function parseSnapshot(values: unknown[][] | undefined): DriverRow[] {
  if (!values?.length) return [];

  const normalize = (value: unknown) =>
    String(value ?? '')
      .replace(/\s+/g, ' ')
      .trim()
      .toUpperCase();
  const sectionSet = new Set<string>(SECTION_TITLES as readonly string[]);
  const toNum = (value: unknown): number => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed || trimmed === '-') return 0;
      const parsed = Number.parseFloat(trimmed.replace(/,/g, ''));
      return Number.isFinite(parsed) ? parsed : 0;
    }
    return 0;
  };

  const toPct = (value: unknown): number | null => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed || trimmed === '-') return null;
      // Accept either 0-1 decimals or percent strings like "39.7%"
      if (trimmed.endsWith('%')) {
        const parsed = Number.parseFloat(
          trimmed.slice(0, -1).replace(/,/g, ''),
        );
        return Number.isFinite(parsed) ? parsed / 100 : null;
      }
      const parsed = Number.parseFloat(trimmed.replace(/,/g, ''));
      return Number.isFinite(parsed) ? parsed : null;
    }
    return null;
  };

  const result: DriverRow[] = [];
  let currentSection: string | null = null;

  for (const row of values) {
    const driverCell = row?.[0];
    const title = normalize(driverCell);

    if (sectionSet.has(title)) {
      currentSection = title;
      continue;
    }
    if (title === 'DRIVER NAME') continue;
    if (
      driverCell === null ||
      driverCell === undefined ||
      String(driverCell).trim() === ''
    ) {
      currentSection = null;
      continue;
    }
    if (typeof driverCell === 'number' || !currentSection) continue;

    result.push({
      section: currentSection,
      driver: String(driverCell),
      cycle1: toNum(row[1]),
      sd12: toNum(row[2]),
      pct12: toPct(row[3]),
      cycle2: toNum(row[4]),
      pickup: toNum(row[5]),
      failed: toNum(row[6]),
      ofd: toNum(row[7]),
      sdOverall: toNum(row[8]),
      pctOverall: toPct(row[9]),
      rowOrder: result.length,
    });
  }

  return result;
}

function parsePofdRows(rows: unknown): PofdRow[] {
  if (!Array.isArray(rows)) return [];

  return rows
    .map(row => {
      if (!row || typeof row !== 'object') return null;
      const item = row as Record<string, unknown>;
      const awb = String(item.awb ?? '').trim();
      const driverName = String(item.driverName ?? '').trim();
      if (!awb || !driverName) return null;
      return {
        entryKey: String(
          item.entryKey ?? `${item.date ?? ''}|${awb}|${driverName}`,
        ),
        date: String(item.date ?? '').trim(),
        awb,
        driverName,
        cancellationReason: String(item.cancellationReason ?? '').trim(),
        shipmentStatus: String(item.shipmentStatus ?? '').trim(),
        result: normalizePofdResult(item.result),
        reason: normalizePofdReason(item.reason),
        inputBy: String(item.inputBy ?? '').trim(),
      } satisfies PofdRow;
    })
    .filter((row): row is PofdRow => row !== null);
}

function normalizePofdResult(value: unknown): PofdResultValue {
  if (value === 'valid' || value === 'invalid') return value;
  return '';
}

function normalizePofdReason(value: unknown): string {
  return String(value ?? '').trim();
}

function normalizePofdDateKey(value: unknown): string {
  if (typeof value === 'number' && Number.isFinite(value)) {
    const larkEpoch = Date.UTC(1899, 11, 30);
    const normalized = new Date(larkEpoch + value * 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);
    return normalized;
  }

  const text = String(value ?? '').trim();
  if (!text) return '';
  const isoMatch = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) return text;
  const slashMatch = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (slashMatch) {
    const [, day, month, year] = slashMatch;
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }
  return text;
}

function matchesExactFilter(value: string, selected: string) {
  if (!selected) return true;
  return value === selected;
}

function getPickupValue(row: DriverRow, pickupView: PickupView) {
  return row[pickupView];
}

function isPickupEligible(selectedPickup: number) {
  return Number.isFinite(selectedPickup) && selectedPickup >= 1;
}

if (isPickupEligible(0) || !isPickupEligible(1) || !isPickupEligible(9999)) {
  throw new Error('Pickup eligibility (>=1) boundaries are invalid');
}

function get12PmPercentage(row: DriverRow): number | null {
  return validPercentage(row.pct12) ? row.pct12 : null;
}

function getOverallPercentage(row: DriverRow): number {
  if (validPercentage(row.pctOverall)) return row.pctOverall;
  if (row.pickup > 0 && row.sdOverall >= 0) {
    const fallback = row.sdOverall / row.pickup;
    if (validPercentage(fallback)) return fallback;
  }
  return 0;
}

function getTierFromSnapshotPercentage(value: number | null) {
  return validPercentage(value) ? getDeliveryTier(value) : null;
}

function getOverallTier(row: DriverRow): DeliveryTier {
  // Special rule requested: if OFD = 0 but still has FTD (>0), classify as Finished!
  if (row.ofd === 0 && row.failed > 0) return 'FINISHED';
  return getDeliveryTier(getOverallPercentage(row));
}

function summarize(rows: DriverRow[], pickupView: PickupView) {
  const pickup = rows.reduce(
    (sum, row) => sum + getPickupValue(row, pickupView),
    0,
  );
  const overallPickup = rows.reduce((sum, row) => sum + row.pickup, 0);
  const sd12 = rows.reduce((sum, row) => sum + row.sd12, 0);
  const delivered = rows.reduce((sum, row) => sum + row.sdOverall, 0);
  return {
    drivers: rows.length,
    active: rows.filter(row => getPickupValue(row, pickupView) > 0).length,
    pickup,
    sd12,
    delivered,
    failed: rows.reduce((sum, row) => sum + row.failed, 0),
    ofd: rows.reduce((sum, row) => sum + row.ofd, 0),
    p12: pickup > 0 ? sd12 / pickup : 0,
    pOverall: overallPickup > 0 ? delivered / overallPickup : 0,
  };
}

type RankingPanelProps = {
  title: string;
  description: string;
  rows: DriverRow[];
  value: (row: DriverRow) => number;
  format: (value: number) => string;
  accentClass: string;
  attention?: boolean;
};

function RankingPanel({
  title,
  description,
  rows,
  value,
  format,
  accentClass,
  attention = false,
}: RankingPanelProps) {
  const maximum = Math.max(...rows.map(value), 0);

  return (
    <Card className="min-w-0 border-sky-200 bg-white/92 text-slate-900 shadow-[0_14px_34px_rgba(14,116,144,.10)]" data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="5"  data-aime-line="487"  data-insp-path="src/routes/page.tsx:487:5:Card" >
      <CardHeader className="pb-3" data-aime-component-name="CardHeader"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="7"  data-aime-line="488"  data-insp-path="src/routes/page.tsx:488:7:CardHeader" >
        <CardTitle data-aime-component-name="CardTitle" data-aime-path-name="src/routes/page.tsx" data-aime-column="9" data-aime-line="489" data-insp-path="src/routes/page.tsx:489:9:CardTitle">{title}</CardTitle>
        <CardDescription
          className={
            attention ? 'font-medium text-amber-700' : 'text-slate-500'
          }
         data-aime-component-name="CardDescription"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="490"  data-insp-path="src/routes/page.tsx:490:9:CardDescription" >
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent data-aime-component-name="CardContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="7" data-aime-line="498" data-insp-path="src/routes/page.tsx:498:7:CardContent">
        {rows.length ? (
          <ol className="space-y-2.5" aria-label={title} data-aime-component-name="ol"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="500"  data-insp-path="src/routes/page.tsx:500:11:ol" >
            {rows.map((row, index) => {
              const metric = value(row);
              const width =
                maximum > 0
                  ? `${Math.max((metric / maximum) * 100, 2)}%`
                  : '0%';
              return (
                <li
                  key={`${title}-${row.section}-${row.driver}-${row.rowOrder}`}
                  className="grid grid-cols-[1.5rem_minmax(0,1fr)_auto] items-center gap-2"
                 data-aime-component-name="li"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="508"  data-insp-path="src/routes/page.tsx:508:17:li" >
                  <span className="text-right text-xs font-bold tabular-nums text-slate-400" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="512"  data-insp-path="src/routes/page.tsx:512:19:span" >
                    {index + 1}
                  </span>
                  <div className="min-w-0" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="515"  data-insp-path="src/routes/page.tsx:515:19:div" >
                    <div
                      className="mb-1 whitespace-normal break-words text-sm font-semibold leading-tight text-slate-800"
                      title={row.driver}
                     data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="516"  data-insp-path="src/routes/page.tsx:516:21:div" >
                      {row.driver}
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-sky-100" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="522"  data-insp-path="src/routes/page.tsx:522:21:div" >
                      <div
                        className={`h-full rounded-full ${accentClass}`}
                        style={{ width }}
                       data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="523"  data-insp-path="src/routes/page.tsx:523:23:div" />
                    </div>
                  </div>
                  <span className="min-w-14 text-right text-sm font-black tabular-nums text-slate-900" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="529"  data-insp-path="src/routes/page.tsx:529:19:span" >
                    {format(metric)}
                  </span>
                </li>
              );
            })}
          </ol>
        ) : (
          <div className="flex min-h-64 items-center justify-center rounded-xl border border-dashed border-sky-200 bg-sky-50/60 text-sm text-slate-500" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="537"  data-insp-path="src/routes/page.tsx:537:11:div" >
            No drivers match the current filters.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

const SIDEBAR_ITEMS = [
  { label: 'Overview', icon: LayoutDashboard, href: '#overview' },
  { label: 'Performance Courier', icon: ListChecks, href: '#driver-detail' },
  { label: 'Driver Rankings', icon: TrendingUp, href: '#trend' },
  { label: 'Pickup & Delivery Status', icon: Building2, href: '#by-section' },
];

function Dashboard() {
  const rows = useMemo(
    () =>
      parseSnapshot((snapshotData as { values?: unknown[][] }).values).filter(
        row => row.pickup > 0,
      ),
    [],
  );
  const pofdRows = useMemo(
    () => parsePofdRows((pofdCheckingData as { rows?: unknown[] }).rows),
    [],
  );
  const pofdReviewDate =
    (pofdCheckingData as { reviewDate?: string }).reviewDate ?? '';
  const reasonFtdSheet = {
    status: 'error' as const,
    data: null as { rawValues?: unknown[][] } | null,
    updateRange: async () => {
      throw new Error('Live sheet editing is available only inside Aime.');
    },
    reload: async () => undefined,
  };
  const pofdLiveBadgeClass =
    reasonFtdSheet.status === 'ready'
      ? 'bg-emerald-700 font-black text-white'
      : reasonFtdSheet.status === 'loading'
        ? 'bg-amber-600 font-black text-white'
        : 'bg-slate-600 font-black text-white';
  const pofdLiveBadgeLabel =
    reasonFtdSheet.status === 'ready'
      ? 'Live edit connected'
      : reasonFtdSheet.status === 'loading'
        ? 'Connecting sheet...'
        : 'Snapshot fallback';
  const snapshotAt = (snapshotData as { snapshotAt?: string }).snapshotAt;
  const cutoff12Pm = (
    snapshotData as {
      cutoff12Pm?: {
        locked?: boolean;
        lockedAt?: string | null;
        cutoff?: string;
      };
    }
  ).cutoff12Pm;
  const pickup12Locked = cutoff12Pm?.locked === true;
  const snapshotLabel = snapshotAt
    ? `${new Intl.DateTimeFormat('en-GB', {
        dateStyle: 'medium',
        timeStyle: 'short',
        timeZone: 'Asia/Shanghai',
      }).format(new Date(snapshotAt))} CST`
    : 'Timestamp unavailable';
  const snapshotWibLabel = snapshotAt
    ? `${new Intl.DateTimeFormat('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Jakarta',
      }).format(new Date(snapshotAt))} WIB`
    : 'Jam tidak tersedia';

  const initialSection = useMemo(() => {
    if (typeof window === 'undefined') return 'ALL SECTIONS';
    const param = new URLSearchParams(window.location.search).get('section');
    return param &&
      DASHBOARD_SECTIONS.includes(param as (typeof DASHBOARD_SECTIONS)[number])
      ? param
      : 'ALL SECTIONS';
  }, []);
  const sections = DASHBOARD_SECTIONS;
  const initialDeliveryStatuses = useMemo<DeliveryTier[]>(() => {
    if (typeof window === 'undefined') return [];
    const allowed = new Set<DeliveryTier>([
      'FAR_FROM_DONE',
      'DECENT',
      'ALL_NICE',
      'FINISHED',
    ]);
    return (new URLSearchParams(window.location.search).get('statuses') ?? '')
      .split(',')
      .filter((status): status is DeliveryTier =>
        allowed.has(status as DeliveryTier),
      );
  }, []);
  const [section, setSection] = useState(initialSection);
  const [activeNav, setActiveNav] = useState(() => {
    if (typeof window === 'undefined') return '#overview';
    const hash = window.location.hash;
    if (hash === '#exceptions') return '#driver-detail';
    return SIDEBAR_ITEMS.some(item => item.href === hash) ? hash : '#overview';
  });
  const [deliveryStatuses, setDeliveryStatuses] = useState<DeliveryTier[]>(
    initialDeliveryStatuses,
  );
  const [tablePage, setTablePage] = useState(1);
  const [driverDetailTab, setDriverDetailTab] =
    useState<DriverDetailTab>('performance');
  const [pofdPage, setPofdPage] = useState(1);
  const [pofdEditingKey, setPofdEditingKey] = useState<string | null>(null);
  const [pofdPendingState, setPofdPendingState] = useState<
    Record<string, PofdReviewState>
  >({});
  const [pofdSyncingKeys, setPofdSyncingKeys] = useState<
    Record<string, boolean>
  >({});
  const [pofdSavedKey, setPofdSavedKey] = useState<string | null>(null);
  const [pofdSyncMessage, setPofdSyncMessage] = useState<string | null>(null);
  const [pofdFilterState, setPofdFilterState] = useState<PofdFilterState>({
    date: '',
    awb: '',
    driverName: '',
    cancellationReason: '',
    result: 'all',
    reason: 'all',
  });

  const toggleDeliveryStatus = (tier: DeliveryTier) => {
    setDeliveryStatuses(prev =>
      prev.includes(tier)
        ? prev.filter(item => item !== tier)
        : [...prev, tier],
    );
  };

  const resetDeliveryStatus = () => setDeliveryStatuses([]);

  const initialPickupView = useMemo<PickupView>(() => {
    if (typeof window === 'undefined') return 'pickup';
    const param = new URLSearchParams(window.location.search).get('pickupView');
    if (param === 'cycle1' || param === 'cycle2' || param === 'pickup') {
      return param;
    }
    const wibHour = Number(
      new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        hour12: false,
      }).format(new Date()),
    );
    return wibHour >= 8 && wibHour < 12 ? 'cycle1' : 'pickup';
  }, []);

  const [pickupView, setPickupView] = useState<PickupView>(initialPickupView);

  useEffect(() => {
    setTablePage(1);
  }, [section, pickupView, deliveryStatuses]);

  useEffect(() => {
    setPofdPage(1);
  }, [driverDetailTab, pofdFilterState]);

  const pofdSheetReviewByKey = useMemo(() => {
    const rawValues = reasonFtdSheet.data?.rawValues ?? [];
    const entries = rawValues.slice(1).flatMap((row, index) => {
      const date = normalizePofdDateKey(row?.[0]);
      const awb = String(row?.[1] ?? '').trim();
      const driverName = String(row?.[2] ?? '').trim();
      const cancellationReason = String(row?.[3] ?? '').trim();
      if (!date || !awb) return [];
      return [
        [
          [date, awb, driverName, cancellationReason].join('|'),
          {
            rowIndex: index + 2,
            result: normalizePofdResult(row?.[4]),
            reason: normalizePofdReason(row?.[5]),
            inputBy: String(row?.[6] ?? '').trim(),
          } satisfies PofdSheetReview,
        ],
      ] as const;
    });
    return new Map<string, PofdSheetReview>(entries);
  }, [reasonFtdSheet.data]);

  const syncPofdRow = useCallback(
    async (row: PofdRow, nextReview: PofdReviewState) => {
      if (reasonFtdSheet.status !== 'ready') {
        setPofdSyncMessage(
          'Draft sudah bisa kamu edit. Untuk kirim ke sheet, tunggu sampai status Live edit connected lalu klik Simpan lagi ya.',
        );
        return;
      }

      const sheetReview = pofdSheetReviewByKey.get(row.entryKey);
      if (!sheetReview) {
        setPofdSyncMessage(
          'Baris ini belum ada di Reason FTD. Jalankan update hourly dulu, baru edit dari dashboard.',
        );
        return;
      }

      setPofdSyncingKeys(prev => ({ ...prev, [row.entryKey]: true }));
      setPofdSyncMessage(null);

      try {
        await reasonFtdSheet.updateRange({
          range: `E${sheetReview.rowIndex}:G${sheetReview.rowIndex}`,
          values: [[
            nextReview.result || '',
            nextReview.reason || '',
            nextReview.inputBy || '',
          ]],
        });
        await reasonFtdSheet.reload();
        setPofdPendingState(prev => {
          const next = { ...prev };
          delete next[row.entryKey];
          return next;
        });
        setPofdSavedKey(row.entryKey);
        if (typeof window !== 'undefined') {
          window.setTimeout(() => {
            setPofdSavedKey(current =>
              current === row.entryKey ? null : current,
            );
          }, 1800);
        }
        setPofdSyncMessage(`Tersimpan ke Reason FTD untuk ${row.awb}.`);
      } catch {
        setPofdSyncMessage(
          'Belum berhasil simpan ke sheet. Refresh/login dulu lalu coba Simpan lagi ya.',
        );
      } finally {
        setPofdSyncingKeys(prev => {
          const next = { ...prev };
          delete next[row.entryKey];
          return next;
        });
      }
    },
    [pofdSheetReviewByKey, reasonFtdSheet],
  );

  const updatePofdResult = useCallback(
    (row: PofdRow, value: PofdResultValue) => {
      setPofdPendingState(prev => {
        const current = prev[row.entryKey] ??
          pofdSheetReviewByKey.get(row.entryKey) ?? {
            result: row.result,
            reason: row.reason,
            inputBy: row.inputBy,
          };
        return {
          ...prev,
          [row.entryKey]: {
            result: value,
            reason: current.reason,
            inputBy: current.inputBy,
          },
        };
      });
      setPofdSavedKey(current => (current === row.entryKey ? null : current));
      setPofdSyncMessage(null);
    },
    [pofdSheetReviewByKey],
  );

  const updatePofdReason = useCallback(
    (row: PofdRow, value: string) => {
      setPofdPendingState(prev => {
        const current = prev[row.entryKey] ??
          pofdSheetReviewByKey.get(row.entryKey) ?? {
            result: row.result,
            reason: row.reason,
            inputBy: row.inputBy,
          };
        return {
          ...prev,
          [row.entryKey]: {
            result: current.result,
            reason: value,
            inputBy: current.inputBy,
          },
        };
      });
      setPofdSavedKey(current => (current === row.entryKey ? null : current));
      setPofdSyncMessage(null);
    },
    [pofdSheetReviewByKey],
  );

  const updatePofdInputBy = useCallback(
    (row: PofdRow, value: string) => {
      setPofdPendingState(prev => {
        const current = prev[row.entryKey] ??
          pofdSheetReviewByKey.get(row.entryKey) ?? {
            result: row.result,
            reason: row.reason,
            inputBy: row.inputBy,
          };
        return {
          ...prev,
          [row.entryKey]: {
            result: current.result,
            reason: current.reason,
            inputBy: value,
          },
        };
      });
      setPofdSavedKey(current => (current === row.entryKey ? null : current));
      setPofdSyncMessage(null);
    },
    [pofdSheetReviewByKey],
  );

  const resetPofdDraft = useCallback((entryKey: string) => {
    setPofdPendingState(prev => {
      const next = { ...prev };
      delete next[entryKey];
      return next;
    });
    setPofdSavedKey(current => (current === entryKey ? null : current));
    setPofdSyncMessage(null);
  }, []);

  const startPofdEditing = useCallback(
    (row: PofdRow) => {
      const savedReview = pofdSheetReviewByKey.get(row.entryKey) ?? {
        result: row.result,
        reason: row.reason,
        inputBy: row.inputBy,
      };
      setPofdPendingState(prev => ({
        ...prev,
        [row.entryKey]: {
          ...savedReview,
          inputBy: savedReview.inputBy || 'Aprianto Aprianto',
        },
      }));
      setPofdEditingKey(row.entryKey);
      setPofdSyncMessage(null);
    },
    [pofdSheetReviewByKey],
  );

  const cancelPofdEditing = useCallback(
    (entryKey: string) => {
      resetPofdDraft(entryKey);
      setPofdEditingKey(null);
    },
    [resetPofdDraft],
  );

  const savePofdDraft = useCallback(
    async (row: PofdRow) => {
      const draft = pofdPendingState[row.entryKey] ??
        pofdSheetReviewByKey.get(row.entryKey) ?? {
          result: row.result,
          reason: row.reason,
          inputBy: row.inputBy,
        };
      await syncPofdRow(row, draft);
      setPofdEditingKey(null);
    },
    [pofdPendingState, pofdSheetReviewByKey, syncPofdRow],
  );

  const reportMode = useMemo(() => {
    if (typeof window === 'undefined') return false;
    const mode = new URLSearchParams(window.location.search).get('mode');
    // default: FULL dashboard mode (dark maroon); use ?mode=report for light report view
    return mode === 'report';
  }, []);

  const sectionFiltered =
    section === 'ALL SECTIONS'
      ? rows
      : rows.filter(row => row.section === section);

  const filtered =
    deliveryStatuses.length === 0
      ? sectionFiltered
      : sectionFiltered.filter(row => {
          const tier =
            pickupView === 'cycle1'
              ? getTierFromSnapshotPercentage(get12PmPercentage(row))
              : getOverallTier(row);
          return tier !== null && deliveryStatuses.includes(tier);
        });

  const tableRows = [...filtered].sort((a, b) => {
    const pickupDiff =
      getPickupValue(b, pickupView) - getPickupValue(a, pickupView);
    if (pickupDiff !== 0) return pickupDiff;
    return a.rowOrder - b.rowOrder;
  });
  const tablePageSize = 15;
  const totalTablePages = Math.max(
    1,
    Math.ceil(tableRows.length / tablePageSize),
  );
  const currentTablePage = Math.min(tablePage, totalTablePages);
  const tableStartIndex = (currentTablePage - 1) * tablePageSize;
  const visibleTableRows = tableRows.slice(
    tableStartIndex,
    tableStartIndex + tablePageSize,
  );
  const pofdDateOptions = useMemo(
    () =>
      [...new Set(pofdRows.map(row => row.date).filter(Boolean))].sort((a, b) =>
        b.localeCompare(a),
      ),
    [pofdRows],
  );
  const pofdAwbOptions = useMemo(
    () => [...new Set(pofdRows.map(row => row.awb).filter(Boolean))].sort(),
    [pofdRows],
  );
  const pofdDriverOptions = useMemo(
    () =>
      [...new Set(pofdRows.map(row => row.driverName).filter(Boolean))].sort(),
    [pofdRows],
  );
  const pofdCancellationOptions = useMemo(
    () =>
      [
        ...new Set(pofdRows.map(row => row.cancellationReason).filter(Boolean)),
      ].sort(),
    [pofdRows],
  );
  const pofdRowsWithReview = useMemo(
    () =>
      pofdRows.map(row => {
        const pendingReview = pofdPendingState[row.entryKey];
        const sheetReview = pofdSheetReviewByKey.get(row.entryKey);
        const savedReview = sheetReview ?? {
          result: row.result,
          reason: row.reason,
          inputBy: row.inputBy,
        };
        const draftReview = pendingReview ?? savedReview;
        const isDirty =
          draftReview.result !== savedReview.result ||
          draftReview.reason !== savedReview.reason ||
          draftReview.inputBy !== savedReview.inputBy;
        return {
          ...row,
          rowIndex: sheetReview?.rowIndex ?? null,
          savedReview,
          draftReview,
          isDirty,
          canSaveNow:
            reasonFtdSheet.status === 'ready' &&
            (sheetReview?.rowIndex ?? null) !== null,
          isSaved: pofdSavedKey === row.entryKey,
          isSyncing: Boolean(pofdSyncingKeys[row.entryKey]),
        };
      }),
    [
      pofdPendingState,
      pofdRows,
      pofdSavedKey,
      pofdSheetReviewByKey,
      pofdSyncingKeys,
      reasonFtdSheet.status,
    ],
  );
  const pofdReasonOptions = useMemo(
    () =>
      [
        ...new Set(
          pofdRowsWithReview
            .map(row => row.draftReview.reason.trim())
            .filter(Boolean),
        ),
      ].sort(),
    [pofdRowsWithReview],
  );
  const filteredPofdRows = useMemo(
    () =>
      pofdRowsWithReview.filter(row => {
        if (!matchesExactFilter(row.date, pofdFilterState.date)) return false;
        if (!matchesExactFilter(row.awb, pofdFilterState.awb)) return false;
        if (!matchesExactFilter(row.driverName, pofdFilterState.driverName)) {
          return false;
        }
        if (
          !matchesExactFilter(
            row.cancellationReason,
            pofdFilterState.cancellationReason,
          )
        ) {
          return false;
        }
        if (pofdFilterState.result !== 'all') {
          const rowResult = row.draftReview.result || 'blank';
          if (rowResult !== pofdFilterState.result) return false;
        }
        if (pofdFilterState.reason !== 'all') {
          const rowReason = row.draftReview.reason || 'blank';
          if (rowReason !== pofdFilterState.reason) return false;
        }
        return true;
      }),
    [pofdFilterState, pofdRowsWithReview],
  );
  const pofdPageSize = 12;
  const totalPofdPages = Math.max(
    1,
    Math.ceil(filteredPofdRows.length / pofdPageSize),
  );
  const currentPofdPage = Math.min(pofdPage, totalPofdPages);
  const pofdStartIndex = (currentPofdPage - 1) * pofdPageSize;
  const visiblePofdRows = filteredPofdRows.slice(
    pofdStartIndex,
    pofdStartIndex + pofdPageSize,
  );
  const editingPofdRow = pofdEditingKey
    ? pofdRowsWithReview.find(row => row.entryKey === pofdEditingKey) ?? null
    : null;

  const selectedPickupLabel =
    PICKUP_VIEWS.find(view => view.key === pickupView)?.tableLabel ?? 'Pick-up';
  const summary = summarize(filtered, pickupView);
  const pickup12Total = filtered.reduce((total, row) => total + row.cycle1, 0);
  const sd12Rate = pickup12Total > 0 ? summary.sd12 / pickup12Total : 0;
  const overallEligibleDrivers = filtered.filter(row =>
    isPickupEligible(row.pickup),
  );
  const qualifyingSd12Drivers = overallEligibleDrivers.filter(
    row => validPercentage(row.pct12) && row.pct12 >= 0.9,
  ).length;
  const qualifyingOverallDrivers = overallEligibleDrivers.filter(
    row => getOverallPercentage(row) >= 0.96,
  ).length;
  const pickupDriverShare = (count: number) =>
    overallEligibleDrivers.length > 0
      ? count / overallEligibleDrivers.length
      : 0;
  const overallDriverShare = pickupDriverShare(qualifyingOverallDrivers);
  const ofdEligibleDrivers = overallEligibleDrivers;
  const qualifyingOfdDrivers = ofdEligibleDrivers.filter(
    row => Number.isFinite(row.ofd) && row.ofd === 0,
  ).length;
  const ofdDriverShare = pickupDriverShare(qualifyingOfdDrivers);
  const eligibleFailed = overallEligibleDrivers.reduce(
    (total, row) => total + row.failed,
    0,
  );
  const rankTieBreaker = (a: DriverRow, b: DriverRow) =>
    getPickupValue(b, pickupView) - getPickupValue(a, pickupView) ||
    a.driver.localeCompare(b.driver, 'id');
  const topSd12 = [...filtered]
    .filter(row => validPercentage(row.pct12))
    .sort(
      (a, b) =>
        (b.pct12 as number) - (a.pct12 as number) || rankTieBreaker(a, b),
    )
    .slice(0, 10);
  const topSdOverall = [...filtered]
    .filter(row => validPercentage(row.pctOverall))
    .sort(
      (a, b) =>
        (b.pctOverall as number) - (a.pctOverall as number) ||
        rankTieBreaker(a, b),
    )
    .slice(0, 10);
  const topFtd = [...filtered]
    .sort((a, b) => b.failed - a.failed || rankTieBreaker(a, b))
    .slice(0, 10);
  const positiveOfdEligibleDrivers = filtered.filter(
    row =>
      isPickupEligible(getPickupValue(row, pickupView)) &&
      Number.isFinite(row.ofd) &&
      row.ofd > 0,
  );
  const topLowestOfd = [...positiveOfdEligibleDrivers]
    .sort((a, b) => a.ofd - b.ofd || rankTieBreaker(a, b))
    .slice(0, 10);
  const topHighestOfd = [...positiveOfdEligibleDrivers]
    .sort((a, b) => b.ofd - a.ofd || rankTieBreaker(a, b))
    .slice(0, 10);
  const sectionRanking = SECTION_TITLES.map(sectionName => {
    const sectionRows = filtered.filter(row => row.section === sectionName);
    return {
      section: sectionName.replace('PONDOK ', 'P. '),
      pickup: summarize(sectionRows, pickupView).pickup,
    };
  }).filter(item => item.pickup > 0);
  const deliveryMetric =
    pickupView === 'cycle1'
      ? {
          label: 'Success Delivered <12PM',
          value: summary.sd12,
          rate: sd12Rate,
          target: 0.9,
        }
      : pickupView === 'pickup'
        ? {
            label: 'Success Delivered Overall',
            value: summary.delivered,
            rate: summary.pOverall,
            target: 0.97,
          }
        : {
            label: 'Cycle 2 Pickup',
            value: summary.pickup,
            rate: null,
            target: null,
          };
  const statusData = [
    {
      name: 'Total Pick-up <12PM',
      value: pickup12Total,
      rate: 1,
      color: '#38bdf8',
    },
    ...(pickupView === 'cycle1'
      ? []
      : [
          {
            name: 'Success Delivered <12PM',
            value: summary.sd12,
            rate: sd12Rate,
            color: '#22c55e',
          },
        ]),
    {
      name: deliveryMetric.label,
      value: deliveryMetric.value,
      rate: deliveryMetric.rate,
      color: '#e11d48',
    },
    {
      name: 'Out for Delivery',
      value: summary.ofd,
      rate: summary.pickup > 0 ? summary.ofd / summary.pickup : 0,
      color: '#f59e0b',
    },
    {
      name: 'Failed',
      value: summary.failed,
      rate: summary.pickup > 0 ? summary.failed / summary.pickup : 0,
      color: '#71717a',
    },
  ];

  // Column visibility rules from annotated screenshots:
  // - Pick-up Cycle 1: hide Overall columns
  // - Pick-up Overall: hide <12PM columns
  // - Pick-up Cycle 2: keep the full current set
  const show12PmColumns = pickupView !== 'pickup';
  const showOverallColumns = pickupView !== 'cycle1';

  return (
    <main
      className={
        reportMode
          ? 'min-h-screen bg-[#F4F5F7] text-slate-900'
          : 'min-h-screen bg-[#C2C6C9] text-[#1B1A1B]'
      }
     data-aime-component-name="main"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="5"  data-aime-line="1194"  data-insp-path="src/routes/page.tsx:1194:5:main" >
      {!reportMode ? (
        <aside className="border-b border-white/10 bg-[#1B1A1B] px-4 py-4 text-[#F6F7F5] shadow-[12px_0_40px_rgba(0,0,0,.20)] lg:fixed lg:inset-y-0 lg:left-0 lg:z-30 lg:h-screen lg:w-80 lg:overflow-y-auto lg:border-b-0 lg:border-r lg:px-7 lg:py-8" data-aime-component-name="aside"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1202"  data-insp-path="src/routes/page.tsx:1202:9:aside" >
          <div className="flex items-center gap-4" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1203"  data-insp-path="src/routes/page.tsx:1203:11:div" >
            <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl shadow-lg shadow-sky-200/60" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1204"  data-insp-path="src/routes/page.tsx:1204:13:div" >
              <img
                src={ongoingCourierLogo}
                alt="Logo Ongoing Courier"
                className="h-full w-full object-contain"
               data-aime-component-name="img"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1205"  data-insp-path="src/routes/page.tsx:1205:15:img" />
            </div>
            <div className="min-w-0" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1211"  data-insp-path="src/routes/page.tsx:1211:13:div" >
              <div className="text-xl font-black tracking-tight text-[#F6F7F5]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1212"  data-insp-path="src/routes/page.tsx:1212:15:div" >
                Ongoing Courier
              </div>
              <div className="mt-1 text-sm text-[#C2C6C9]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1215"  data-insp-path="src/routes/page.tsx:1215:15:div" >
                Operasional Rider
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-2xl border border-sky-200 bg-white/90 p-4 shadow-[0_14px_36px_rgba(14,116,144,.10)]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1221"  data-insp-path="src/routes/page.tsx:1221:11:div" >
            <div className="text-sm font-black text-slate-900" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1222"  data-insp-path="src/routes/page.tsx:1222:13:div" >Controls</div>
            <div className="mt-1 text-xs text-slate-500" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1223"  data-insp-path="src/routes/page.tsx:1223:13:div" >Dashboard filters</div>

            <label
              className="mt-4 block text-xs font-black uppercase tracking-wider"
              style={{ color: '#1B1A1B' }}
             data-aime-component-name="label"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1225"  data-insp-path="src/routes/page.tsx:1225:13:label" >
              Section
              <select
                value={section}
                onChange={event => setSection(event.target.value)}
                className="mt-1.5 h-9 w-full rounded-lg border border-sky-200 bg-[#f8fcff] px-3 text-xs font-semibold text-slate-900 outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200"
               data-aime-component-name="select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1230"  data-insp-path="src/routes/page.tsx:1230:15:select" >
                {sections.map(item => (
                  <option key={item} value={item} data-aime-component-name="option"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1236"  data-insp-path="src/routes/page.tsx:1236:19:option" >
                    {item}
                  </option>
                ))}
              </select>
            </label>

            <label
              className="mt-3 block text-xs font-black uppercase tracking-wider"
              style={{ color: '#1B1A1B' }}
             data-aime-component-name="label"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1243"  data-insp-path="src/routes/page.tsx:1243:13:label" >
              Pickup View
              <select
                value={pickupView}
                onChange={event =>
                  setPickupView(event.target.value as PickupView)
                }
                className="mt-1.5 h-9 w-full rounded-lg border border-sky-200 bg-[#f8fcff] px-3 text-xs font-semibold text-slate-900 outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-200"
               data-aime-component-name="select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1248"  data-insp-path="src/routes/page.tsx:1248:15:select" >
                {PICKUP_VIEWS.map(view => (
                  <option key={view.key} value={view.key} data-aime-component-name="option"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1256"  data-insp-path="src/routes/page.tsx:1256:19:option" >
                    {view.label}
                  </option>
                ))}
              </select>
            </label>

            <div
              className="mt-3 text-xs font-black uppercase tracking-wider"
              style={{ color: '#1B1A1B' }}
             data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1263"  data-insp-path="src/routes/page.tsx:1263:13:div" >
              Overall Status
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1269"  data-insp-path="src/routes/page.tsx:1269:13:div" >
              {DELIVERY_STATUSES.map(status => {
                const isSelected =
                  status.key === 'ALL'
                    ? deliveryStatuses.length === 0
                    : deliveryStatuses.includes(status.key);
                return (
                  <button
                    key={status.key}
                    type="button"
                    onClick={() => {
                      if (status.key === 'ALL') setDeliveryStatuses([]);
                      else toggleDeliveryStatus(status.key);
                    }}
                    className={
                      isSelected
                        ? 'rounded-lg bg-[#AE7EFD] px-2.5 py-1.5 text-[11px] font-bold text-[#1B1A1B] shadow-sm'
                        : 'rounded-lg border border-sky-200 bg-sky-50 px-2.5 py-1.5 text-[11px] font-bold text-slate-800 hover:bg-sky-100'
                    }
                   data-aime-component-name="button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1276"  data-insp-path="src/routes/page.tsx:1276:19:button" >
                    {status.label.replace('All Overall Status', 'All')}
                  </button>
                );
              })}
            </div>
          </div>

          <nav
            className="mt-5 flex gap-2 overflow-x-auto pb-1 lg:block lg:space-y-2 lg:overflow-visible"
            aria-label="Dashboard navigation"
           data-aime-component-name="nav"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1296"  data-insp-path="src/routes/page.tsx:1296:11:nav" >
            {SIDEBAR_ITEMS.map(item => {
              const Icon = item.icon;
              return (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={event => {
                    event.preventDefault();
                    setActiveNav(item.href);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  aria-current={activeNav === item.href ? 'page' : undefined}
                  className={
                    activeNav === item.href
                      ? 'flex shrink-0 items-center gap-3 rounded-2xl border-2 border-[#CEE36B] bg-[#CEE36B] px-4 py-3 font-semibold text-[#1B1A1B] shadow-[0_10px_24px_rgba(206,227,107,.20)] lg:py-4'
                      : 'flex shrink-0 items-center gap-3 rounded-2xl border-2 border-transparent px-4 py-3 font-bold text-white transition hover:border-[#AE7EFD] hover:bg-[#AE7EFD] hover:text-[#1B1A1B] lg:py-4'
                  }
                 data-aime-component-name="a"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1303"  data-insp-path="src/routes/page.tsx:1303:17:a" >
                  <Icon className="h-5 w-5"  data-aime-component-name="Icon"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1318"  data-insp-path="src/routes/page.tsx:1318:19:Icon" />
                  <span data-aime-component-name="span" data-aime-path-name="src/routes/page.tsx" data-aime-column="19" data-aime-line="1319" data-insp-path="src/routes/page.tsx:1319:19:span">{item.label}</span>
                </a>
              );
            })}
          </nav>

          <div className="mt-8 hidden border-t border-white/20 pt-6 text-sm font-medium leading-6 text-white lg:block" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1325"  data-insp-path="src/routes/page.tsx:1325:11:div" >
            <div className="font-bold text-slate-700" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1326"  data-insp-path="src/routes/page.tsx:1326:13:div" >Static dashboard</div>
            <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1327" data-insp-path="src/routes/page.tsx:1327:13:div">No API calls on page open.</div>
            <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1328" data-insp-path="src/routes/page.tsx:1328:13:div">Data is refreshed offline and embedded inline.</div>
          </div>
        </aside>
      ) : null}

      <div
        className={
          reportMode
            ? 'mx-auto flex max-w-[1600px] flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8'
            : 'mx-auto flex max-w-[1600px] flex-col gap-6 px-4 py-6 sm:px-6 lg:px-8 lg:pl-[22rem]'
        }
       data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="7"  data-aime-line="1333"  data-insp-path="src/routes/page.tsx:1333:7:div" >
        {!reportMode && activeNav !== '#overview' ? (
          <div className="rounded-2xl border border-sky-200 bg-white/90 px-6 py-5 shadow-[0_14px_36px_rgba(14,116,144,.10)]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1341"  data-insp-path="src/routes/page.tsx:1341:11:div" >
            <div className="text-xs font-bold uppercase tracking-[0.2em] text-sky-600" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1342"  data-insp-path="src/routes/page.tsx:1342:13:div" >
              Ongoing Courier
            </div>
            <h1 className="mt-1 text-2xl font-black text-slate-900" data-aime-component-name="h1"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1345"  data-insp-path="src/routes/page.tsx:1345:13:h1" >
              {SIDEBAR_ITEMS.find(item => item.href === activeNav)?.label}
            </h1>
          </div>
        ) : null}
        <header
          id="overview"
          style={{ display: activeNav === '#overview' ? undefined : 'none' }}
          className={
            reportMode
              ? 'overflow-hidden rounded-2xl border border-slate-200 bg-[#172B4D] p-6 shadow'
              : 'overflow-hidden rounded-3xl border border-black/15 bg-[#1B1A1B] p-6 text-[#F6F7F5] shadow-[0_20px_50px_rgba(0,0,0,.18)]'
          }
         data-aime-component-name="header"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1350"  data-insp-path="src/routes/page.tsx:1350:9:header" >
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1359"  data-insp-path="src/routes/page.tsx:1359:11:div" >
            <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1360" data-insp-path="src/routes/page.tsx:1360:13:div">
              <Badge
                className={
                  reportMode
                    ? 'mb-3 bg-white/15 text-white hover:bg-white/15'
                    : 'mb-3 bg-[#CEE36B] text-[#1B1A1B] hover:bg-[#CEE36B]'
                }
               data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1361"  data-insp-path="src/routes/page.tsx:1361:15:Badge" >
                Ongoing Operations
              </Badge>
              <h1
                className={
                  reportMode
                    ? 'text-3xl font-bold tracking-tight text-white sm:text-4xl'
                    : 'text-3xl font-bold tracking-tight sm:text-5xl'
                }
               data-aime-component-name="h1"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1370"  data-insp-path="src/routes/page.tsx:1370:15:h1" >
                Dashboard Operasional Driver
              </h1>
              <p
                className={
                  reportMode
                    ? 'mt-2 text-sm text-white/80'
                    : 'mt-2 text-sm font-black text-[#C2C6C9]'
                }
               data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1379"  data-insp-path="src/routes/page.tsx:1379:15:p" >
                Snapshot dari Sheet Ongoing (PDeCYf) — harus sama persis.
              </p>
              <p
                className={
                  reportMode
                    ? 'mt-1 text-xs text-white/70'
                    : 'mt-1 text-xs text-slate-500'
                }
               data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1388"  data-insp-path="src/routes/page.tsx:1388:15:p" >
                Source:{' '}
                <a
                  className={
                    reportMode
                      ? 'underline decoration-white/70 underline-offset-4'
                      : 'underline decoration-sky-500 underline-offset-4'
                  }
                  href={SOURCE_URL}
                  target="_blank"
                  rel="noreferrer"
                 data-aime-component-name="a"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1396"  data-insp-path="src/routes/page.tsx:1396:17:a" >
                  Sheet Ongoing
                </a>{' '}
                · Data as of {snapshotLabel}
              </p>
            </div>
            <div className="rounded-2xl border border-black/20 bg-[#F6F7F5] px-4 py-3 text-right text-sm text-[#1B1A1B] shadow-sm" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1411"  data-insp-path="src/routes/page.tsx:1411:13:div" >
              <div className="font-semibold text-[#334155]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1412"  data-insp-path="src/routes/page.tsx:1412:15:div" >
                Rows in embedded snapshot
              </div>
              <div className="font-black text-[#1B1A1B]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1415"  data-insp-path="src/routes/page.tsx:1415:15:div" >
                {rows.length} drivers
              </div>
              <div className="text-xs font-medium text-[#475569]" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1418"  data-insp-path="src/routes/page.tsx:1418:15:div" >
                Main content simplified to controls and table only
              </div>
            </div>
          </div>
        </header>

        <Card style={{ display: 'none' }} data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1425"  data-insp-path="src/routes/page.tsx:1425:9:Card" >
          <CardHeader className="space-y-3 py-4" data-aime-component-name="CardHeader"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1426"  data-insp-path="src/routes/page.tsx:1426:11:CardHeader" >
            <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1427" data-insp-path="src/routes/page.tsx:1427:13:div">
              <CardTitle data-aime-component-name="CardTitle" data-aime-path-name="src/routes/page.tsx" data-aime-column="15" data-aime-line="1428" data-insp-path="src/routes/page.tsx:1428:15:CardTitle">Controls</CardTitle>
              <CardDescription
                className={
                  reportMode ? 'font-black text-slate-800' : 'text-slate-500'
                }
               data-aime-component-name="CardDescription"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1429"  data-insp-path="src/routes/page.tsx:1429:15:CardDescription" >
                Keep Section, Pickup View, and Overall Status filters for table
                filtering.
              </CardDescription>
            </div>
            <div className="space-y-3" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1438"  data-insp-path="src/routes/page.tsx:1438:13:div" >
              <div className="flex flex-wrap items-center gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1439"  data-insp-path="src/routes/page.tsx:1439:15:div" >
                <span className="text-xs font-semibold uppercase tracking-wide text-zinc-500" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1440"  data-insp-path="src/routes/page.tsx:1440:17:span" >
                  Section:
                </span>
                {sections.map(item => (
                  <Button
                    key={item}
                    onClick={() => setSection(item)}
                    className={
                      item === section
                        ? 'h-8 bg-red-700 px-3 text-xs text-white hover:bg-red-800'
                        : 'h-8 bg-zinc-900 px-3 text-xs font-bold text-slate-200 hover:bg-zinc-800'
                    }
                   data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1444"  data-insp-path="src/routes/page.tsx:1444:19:Button" >
                    {item}
                  </Button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1457"  data-insp-path="src/routes/page.tsx:1457:15:div" >
                <span className="text-xs font-semibold uppercase tracking-wide text-zinc-500" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1458"  data-insp-path="src/routes/page.tsx:1458:17:span" >
                  Pickup View:
                </span>
                {PICKUP_VIEWS.map(view => (
                  <Button
                    key={view.key}
                    onClick={() => setPickupView(view.key)}
                    className={
                      view.key === pickupView
                        ? 'h-8 bg-red-700 px-3 text-xs text-white hover:bg-red-800'
                        : 'h-8 bg-zinc-900 px-3 text-xs font-bold text-slate-200 hover:bg-zinc-800'
                    }
                   data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1462"  data-insp-path="src/routes/page.tsx:1462:19:Button" >
                    {view.label}
                  </Button>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1475"  data-insp-path="src/routes/page.tsx:1475:15:div" >
                <span className="text-xs font-semibold uppercase tracking-wide text-zinc-500" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1476"  data-insp-path="src/routes/page.tsx:1476:17:span" >
                  Overall Status:
                </span>
                {DELIVERY_STATUSES.map(status => {
                  const isAll = status.key === 'ALL';
                  const isSelected = isAll
                    ? deliveryStatuses.length === 0
                    : deliveryStatuses.includes(status.key as DeliveryTier);
                  return (
                    <Button
                      key={status.key}
                      onClick={() => {
                        if (isAll) {
                          resetDeliveryStatus();
                          return;
                        }
                        toggleDeliveryStatus(status.key as DeliveryTier);
                      }}
                      className={
                        isSelected
                          ? `h-8 px-3 text-xs ${status.activeClass}`
                          : 'h-8 bg-zinc-900 px-3 text-xs font-bold text-slate-200 hover:bg-zinc-800'
                      }
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1485"  data-insp-path="src/routes/page.tsx:1485:21:Button" >
                      {status.label}
                    </Button>
                  );
                })}
              </div>
            </div>
          </CardHeader>
        </Card>

        <section
          id="performance"
          style={{ display: activeNav === '#overview' ? undefined : 'none' }}
          className="scroll-mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"
          data-source="filtered-driver-kpis"
          aria-label="Filtered driver performance KPIs"
         data-aime-component-name="section"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1509"  data-insp-path="src/routes/page.tsx:1509:9:section" >
          {[
            {
              label: 'SD <12PM ≥90%',
              value: qualifyingSd12Drivers,
              note: `${pct(pickupDriverShare(qualifyingSd12Drivers))} of ${overallEligibleDrivers.length.toLocaleString('id-ID')} drivers with Pick-up Overall ≥1`,
              icon: <Clock3 className="h-6 w-6"  data-aime-component-name="Clock3"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1521"  data-insp-path="src/routes/page.tsx:1521:21:Clock3" />,
              testId: 'kpi-sd12-target',
            },
            {
              label: 'SD Overall ≥96%',
              value: qualifyingOverallDrivers,
              note: `${pct(overallDriverShare)} of ${overallEligibleDrivers.length.toLocaleString('id-ID')} drivers with Pick-up Overall ≥1 · 96% threshold`,
              icon: <CheckCircle2 className="h-6 w-6"  data-aime-component-name="CheckCircle2"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1528"  data-insp-path="src/routes/page.tsx:1528:21:CheckCircle2" />,
              testId: 'kpi-overall-target',
            },
            {
              label: 'OFD Done (=0)',
              value: qualifyingOfdDrivers,
              note: `${pct(ofdDriverShare)} of ${ofdEligibleDrivers.length.toLocaleString('id-ID')} drivers with Pick-up Overall ≥1 · OFD from column H is 0`,
              icon: <Truck className="h-6 w-6"  data-aime-component-name="Truck"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1535"  data-insp-path="src/routes/page.tsx:1535:21:Truck" />,
              testId: 'kpi-ofd-done',
            },
            {
              label: 'FTD',
              value: eligibleFailed,
              note: `Total Failed To Deliver · ${overallEligibleDrivers.length.toLocaleString('id-ID')} drivers with Pick-up Overall ≥1`,
              icon: <AlertTriangle className="h-6 w-6"  data-aime-component-name="AlertTriangle"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1542"  data-insp-path="src/routes/page.tsx:1542:21:AlertTriangle" />,
              testId: 'kpi-ftd',
            },
          ].map(item => (
            <Card
              key={item.label}
              data-testid={item.testId}
              className="overflow-hidden border-sky-200 bg-white/92 text-slate-900 shadow-[0_14px_34px_rgba(14,116,144,.10)]"
             data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1546"  data-insp-path="src/routes/page.tsx:1546:13:Card" >
              <CardContent className="flex items-center justify-between gap-4 p-6" data-aime-component-name="CardContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1551"  data-insp-path="src/routes/page.tsx:1551:15:CardContent" >
                <div className="min-w-0" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1552"  data-insp-path="src/routes/page.tsx:1552:17:div" >
                  <div className="text-sm font-bold uppercase tracking-wider text-sky-700" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1553"  data-insp-path="src/routes/page.tsx:1553:19:div" >
                    {item.label}
                  </div>
                  <div className="mt-2 text-4xl font-black text-slate-950" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1556"  data-insp-path="src/routes/page.tsx:1556:19:div" >
                    {item.value.toLocaleString('id-ID')}
                  </div>
                  <p className="mt-2 text-sm font-medium text-[#1B1A1B]" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1559"  data-insp-path="src/routes/page.tsx:1559:19:p" >
                    {item.note}
                  </p>
                </div>
                <span className="shrink-0 rounded-2xl border border-sky-200 bg-[linear-gradient(145deg,#e0f2fe,#f0f9ff)] p-4 text-sky-700" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1563"  data-insp-path="src/routes/page.tsx:1563:17:span" >
                  {item.icon}
                </span>
              </CardContent>
            </Card>
          ))}
        </section>

        <section
          style={{ display: activeNav === '#overview' ? undefined : 'none' }}
          className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5"
         data-aime-component-name="section"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1571"  data-insp-path="src/routes/page.tsx:1571:9:section" >
          {[
            {
              label: 'Drivers in view',
              value: summary.drivers,
              note: `${summary.active} with ${selectedPickupLabel}`,
              icon: <Truck className="h-5 w-5"  data-aime-component-name="Truck"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1580"  data-insp-path="src/routes/page.tsx:1580:21:Truck" />,
            },
            {
              label: selectedPickupLabel,
              value: summary.pickup,
              note: 'Exact selected pickup column',
              icon: <Clock3 className="h-5 w-5"  data-aime-component-name="Clock3"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1586"  data-insp-path="src/routes/page.tsx:1586:21:Clock3" />,
            },
            {
              label: deliveryMetric.label,
              value: deliveryMetric.value,
              note:
                deliveryMetric.rate === null
                  ? 'Neutral operational count'
                  : `${pct(deliveryMetric.rate)} · target ${pct(deliveryMetric.target)}`,
              icon:
                pickupView === 'cycle2' ? (
                  <Activity className="h-5 w-5"  data-aime-component-name="Activity"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1597"  data-insp-path="src/routes/page.tsx:1597:19:Activity" />
                ) : (
                  <PackageCheck className="h-5 w-5"  data-aime-component-name="PackageCheck"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1599"  data-insp-path="src/routes/page.tsx:1599:19:PackageCheck" />
                ),
            },
            {
              label: 'Out for Delivery',
              value: summary.ofd,
              note: 'Packages in progress',
              icon: <Activity className="h-5 w-5"  data-aime-component-name="Activity"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1606"  data-insp-path="src/routes/page.tsx:1606:21:Activity" />,
            },
            {
              label: 'Visible context',
              value:
                pickupView === 'cycle1'
                  ? '<12PM'
                  : pickupView === 'pickup'
                    ? 'Overall'
                    : 'Cycle 2',
              note:
                deliveryStatuses.length === 0
                  ? 'All Overall Status'
                  : deliveryStatuses
                      .map(status => TIER_LABEL[status])
                      .join(', '),
              icon: <CheckCircle2 className="h-5 w-5"  data-aime-component-name="CheckCircle2"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1622"  data-insp-path="src/routes/page.tsx:1622:21:CheckCircle2" />,
            },
          ].map(item => (
            <Card
              key={item.label}
              className="group overflow-hidden border-sky-200 bg-white/92 text-slate-900 shadow-[0_12px_30px_rgba(14,116,144,.09)] transition-transform hover:-translate-y-1"
             data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1625"  data-insp-path="src/routes/page.tsx:1625:13:Card" >
              <CardContent className="p-5" data-aime-component-name="CardContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1629"  data-insp-path="src/routes/page.tsx:1629:15:CardContent" >
                <div className="mb-5 flex items-start justify-between gap-2 text-sky-700" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1630"  data-insp-path="src/routes/page.tsx:1630:17:div" >
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-500" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1631"  data-insp-path="src/routes/page.tsx:1631:19:span" >
                    {item.label}
                  </span>
                  <span className="rounded-xl bg-sky-50 p-2" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1634"  data-insp-path="src/routes/page.tsx:1634:19:span" >{item.icon}</span>
                </div>
                <div className="truncate text-3xl font-bold text-slate-950" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1636"  data-insp-path="src/routes/page.tsx:1636:17:div" >
                  {typeof item.value === 'number'
                    ? item.value.toLocaleString('id-ID')
                    : item.value}
                </div>
                <p className="mt-2 truncate text-xs text-slate-500" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1641"  data-insp-path="src/routes/page.tsx:1641:17:p" >
                  {item.note}
                </p>
              </CardContent>
            </Card>
          ))}
        </section>

        <section
          id="trend"
          style={{ display: activeNav === '#trend' ? undefined : 'none' }}
          className="scroll-mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-5"
          aria-label="Top 10 driver rankings"
         data-aime-component-name="section"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1649"  data-insp-path="src/routes/page.tsx:1649:9:section" >
          {activeNav === '#trend' ? (
            <>
              <RankingPanel
                title="Top 10 SD <12PM"
                description="Column D percentage, highest first. Ties: pickup descending, then driver name."
                rows={topSd12}
                value={row => row.pct12 ?? 0}
                format={value => pct(value)}
                accentClass="bg-gradient-to-r from-rose-700 to-rose-400"
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1657"  data-insp-path="src/routes/page.tsx:1657:15:RankingPanel" />
              <RankingPanel
                title="Top 10 SD Overall"
                description="Column J percentage, highest first. Ties: pickup descending, then driver name."
                rows={topSdOverall}
                value={row => row.pctOverall ?? 0}
                format={value => pct(value)}
                accentClass="bg-gradient-to-r from-red-800 to-red-400"
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1665"  data-insp-path="src/routes/page.tsx:1665:15:RankingPanel" />
              <RankingPanel
                title="Top 10 Lowest Positive OFD"
                description={`Eligible only when ${selectedPickupLabel} ≥1 and OFD >0. OFD uses column H, lowest positive first. Ties: selected pickup descending, then driver name.`}
                rows={topLowestOfd}
                value={row => row.ofd}
                format={value => value.toLocaleString('id-ID')}
                accentClass="bg-gradient-to-r from-emerald-700 to-emerald-400"
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1673"  data-insp-path="src/routes/page.tsx:1673:15:RankingPanel" />
            </>
          ) : (
            <>
              <RankingPanel
                title="Top 10 Highest OFD"
                description={`Attention / risk list — higher OFD needs attention. Eligible only when ${selectedPickupLabel} ≥1 and OFD >0. OFD uses column H, highest first. Ties: selected pickup descending, then driver name.`}
                rows={topHighestOfd}
                value={row => row.ofd}
                format={value => value.toLocaleString('id-ID')}
                accentClass="bg-gradient-to-r from-red-800 to-amber-400"
                attention
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1684"  data-insp-path="src/routes/page.tsx:1684:15:RankingPanel" />
              <RankingPanel
                title="Top 10 FTD"
                description="Higher means more FTD — attention needed. Ties: pickup descending, then driver name."
                rows={topFtd}
                value={row => row.failed}
                format={value => value.toLocaleString('id-ID')}
                accentClass="bg-gradient-to-r from-amber-700 to-amber-400"
                attention
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1693"  data-insp-path="src/routes/page.tsx:1693:15:RankingPanel" />
            </>
          )}
          {activeNav === '#trend' ? (
            <>
              <RankingPanel
                title="Top 10 Highest OFD"
                description={`Attention / risk list — higher OFD needs attention. Eligible only when ${selectedPickupLabel} ≥1 and OFD >0. OFD uses column H, highest first. Ties: selected pickup descending, then driver name.`}
                rows={topHighestOfd}
                value={row => row.ofd}
                format={value => value.toLocaleString('id-ID')}
                accentClass="bg-gradient-to-r from-red-800 to-amber-400"
                attention
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1706"  data-insp-path="src/routes/page.tsx:1706:15:RankingPanel" />
              <RankingPanel
                title="Top 10 FTD"
                description="Higher means more FTD — attention needed. Ties: pickup descending, then driver name."
                rows={topFtd}
                value={row => row.failed}
                format={value => value.toLocaleString('id-ID')}
                accentClass="bg-gradient-to-r from-amber-700 to-amber-400"
                attention
               data-aime-component-name="RankingPanel"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1715"  data-insp-path="src/routes/page.tsx:1715:15:RankingPanel" />
            </>
          ) : null}
        </section>

        <section
          id="alerts"
          style={{ display: activeNav === '#by-section' ? undefined : 'none' }}
          className="scroll-mt-6 grid gap-4"
         data-aime-component-name="section"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1728"  data-insp-path="src/routes/page.tsx:1728:9:section" >
          <Card className="min-w-0 border-sky-200 bg-white/92 text-slate-900 shadow-[0_14px_34px_rgba(14,116,144,.10)]" data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1733"  data-insp-path="src/routes/page.tsx:1733:11:Card" >
            <CardHeader data-aime-component-name="CardHeader" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1734" data-insp-path="src/routes/page.tsx:1734:13:CardHeader">
              <CardTitle data-aime-component-name="CardTitle" data-aime-path-name="src/routes/page.tsx" data-aime-column="15" data-aime-line="1735" data-insp-path="src/routes/page.tsx:1735:15:CardTitle">
                {pickupView === 'cycle1'
                  ? '<12PM delivery context'
                  : pickupView === 'pickup'
                    ? 'Overall delivery context'
                    : 'Cycle 2 operations'}
              </CardTitle>
              <CardDescription
                className={
                  reportMode ? 'font-black text-slate-800' : 'text-slate-500'
                }
               data-aime-component-name="CardDescription"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1742"  data-insp-path="src/routes/page.tsx:1742:15:CardDescription" >
                Update {snapshotWibLabel} · Total Pick-up {'<12PM'}:{' '}
                {pickup12Total.toLocaleString('id-ID')} paket · Total{' '}
                {selectedPickupLabel}: {summary.pickup.toLocaleString('id-ID')}{' '}
                paket
              </CardDescription>
              <div className="grid gap-2 pt-2 sm:grid-cols-2 xl:grid-cols-5" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1752"  data-insp-path="src/routes/page.tsx:1752:15:div" >
                {statusData.map(item => (
                  <div
                    key={item.name}
                    className="rounded-xl border border-sky-200 bg-sky-50/80 px-3 py-2 shadow-sm"
                   data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1754"  data-insp-path="src/routes/page.tsx:1754:19:div" >
                    <div className="flex items-center justify-between gap-1 text-[11px] font-semibold text-slate-500" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1758"  data-insp-path="src/routes/page.tsx:1758:21:div" >
                      <span className="truncate" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="1759"  data-insp-path="src/routes/page.tsx:1759:23:span" >{item.name}</span>
                      {item.name === 'Total Pick-up <12PM' ? (
                        <span
                          className={`shrink-0 rounded-full px-2 py-0.5 text-[8px] font-black uppercase tracking-wide ${
                            pickup12Locked
                              ? 'bg-emerald-600 text-white'
                              : 'bg-sky-200 text-sky-800'
                          }`}
                         data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1761"  data-insp-path="src/routes/page.tsx:1761:25:span" >
                          {pickup12Locked
                            ? 'Locked 12:00 WIB'
                            : 'Locks 12:00 WIB'}
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-1 flex items-end justify-between gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1774"  data-insp-path="src/routes/page.tsx:1774:21:div" >
                      <span className="text-lg font-black text-slate-900" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="1775"  data-insp-path="src/routes/page.tsx:1775:23:span" >
                        {item.value.toLocaleString('id-ID')}
                      </span>
                      <span className="text-xs font-bold text-sky-700" data-aime-component-name="span"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="1778"  data-insp-path="src/routes/page.tsx:1778:23:span" >
                        {item.rate === null ? '-' : pct(item.rate)}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="1782"  data-insp-path="src/routes/page.tsx:1782:21:div" >
                      total paket · persen
                    </div>
                  </div>
                ))}
              </div>
            </CardHeader>
            <CardContent className="h-96 min-w-0" data-aime-component-name="CardContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1789"  data-insp-path="src/routes/page.tsx:1789:13:CardContent" >
              <ResponsiveContainer width="100%" height="100%" data-aime-component-name="ResponsiveContainer"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1790"  data-insp-path="src/routes/page.tsx:1790:15:ResponsiveContainer" >
                <BarChart
                  data={statusData}
                  margin={{ left: 0, right: 10, bottom: 35 }}
                 data-aime-component-name="BarChart"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1791"  data-insp-path="src/routes/page.tsx:1791:17:BarChart" >
                  <CartesianGrid strokeDasharray="3 3" stroke="#dbeafe"  data-aime-component-name="CartesianGrid"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1795"  data-insp-path="src/routes/page.tsx:1795:19:CartesianGrid" />
                  <XAxis
                    dataKey="name"
                    stroke="#64748b"
                    interval={0}
                    angle={-12}
                    textAnchor="end"
                    tick={{ fontSize: 10 }}
                    height={65}
                   data-aime-component-name="XAxis"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1796"  data-insp-path="src/routes/page.tsx:1796:19:XAxis" />
                  <YAxis stroke="#64748b"  data-aime-component-name="YAxis"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1805"  data-insp-path="src/routes/page.tsx:1805:19:YAxis" />
                  <Tooltip
                    contentStyle={{
                      background: '#ffffff',
                      border: '1px solid #bae6fd',
                      color: '#0f172a',
                    }}
                   data-aime-component-name="Tooltip"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1806"  data-insp-path="src/routes/page.tsx:1806:19:Tooltip" />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} data-aime-component-name="Bar"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1813"  data-insp-path="src/routes/page.tsx:1813:19:Bar" >
                    {statusData.map(item => (
                      <Cell key={item.name} fill={item.color}  data-aime-component-name="Cell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="1815"  data-insp-path="src/routes/page.tsx:1815:23:Cell" />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </section>

        <Card
          id="by-section"
          style={{ display: activeNav === '#by-section' ? undefined : 'none' }}
          className="scroll-mt-6 min-w-0 border-sky-200 bg-white/92 text-slate-900 shadow-[0_14px_34px_rgba(14,116,144,.10)]"
         data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1824"  data-insp-path="src/routes/page.tsx:1824:9:Card" >
          <CardHeader data-aime-component-name="CardHeader" data-aime-path-name="src/routes/page.tsx" data-aime-column="11" data-aime-line="1829" data-insp-path="src/routes/page.tsx:1829:11:CardHeader">
            <CardTitle data-aime-component-name="CardTitle" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1830" data-insp-path="src/routes/page.tsx:1830:13:CardTitle">Pickup by section</CardTitle>
            <CardDescription
              className={
                reportMode ? 'font-black text-slate-800' : 'text-slate-500'
              }
             data-aime-component-name="CardDescription"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1831"  data-insp-path="src/routes/page.tsx:1831:13:CardDescription" >
              {selectedPickupLabel} ranking across visible sections.
            </CardDescription>
          </CardHeader>
          <CardContent className="h-72 min-w-0" data-aime-component-name="CardContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1839"  data-insp-path="src/routes/page.tsx:1839:11:CardContent" >
            <ResponsiveContainer width="100%" height="100%" data-aime-component-name="ResponsiveContainer"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1840"  data-insp-path="src/routes/page.tsx:1840:13:ResponsiveContainer" >
              <BarChart
                data={sectionRanking}
                margin={{ left: 6, right: 18, bottom: 35 }}
               data-aime-component-name="BarChart"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1841"  data-insp-path="src/routes/page.tsx:1841:15:BarChart" >
                <CartesianGrid strokeDasharray="3 3" stroke="#dbeafe"  data-aime-component-name="CartesianGrid"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1845"  data-insp-path="src/routes/page.tsx:1845:17:CartesianGrid" />
                <XAxis
                  dataKey="section"
                  stroke="#64748b"
                  interval={0}
                  angle={-12}
                  textAnchor="end"
                  tick={{ fontSize: 10 }}
                  height={65}
                 data-aime-component-name="XAxis"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1846"  data-insp-path="src/routes/page.tsx:1846:17:XAxis" />
                <YAxis stroke="#64748b"  data-aime-component-name="YAxis"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1855"  data-insp-path="src/routes/page.tsx:1855:17:YAxis" />
                <Tooltip
                  contentStyle={{
                    background: '#ffffff',
                    border: '1px solid #bae6fd',
                    color: '#0f172a',
                  }}
                 data-aime-component-name="Tooltip"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1856"  data-insp-path="src/routes/page.tsx:1856:17:Tooltip" />
                <Bar
                  dataKey="pickup"
                  name={selectedPickupLabel}
                  fill="#0284c7"
                  radius={[8, 8, 0, 0]}
                 data-aime-component-name="Bar"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1863"  data-insp-path="src/routes/page.tsx:1863:17:Bar" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card
          id="driver-detail"
          style={{
            display: activeNav === '#driver-detail' ? undefined : 'none',
          }}
          className={
            reportMode
              ? 'scroll-mt-6 border-slate-200 bg-white text-slate-900'
              : 'scroll-mt-6 border-sky-200 bg-white/92 text-slate-900 shadow-[0_14px_34px_rgba(14,116,144,.10)]'
          }
         data-aime-component-name="Card"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="1874"  data-insp-path="src/routes/page.tsx:1874:9:Card" >
          <CardHeader className="pb-3" data-aime-component-name="CardHeader"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="11"  data-aime-line="1885"  data-insp-path="src/routes/page.tsx:1885:11:CardHeader" >
            <CardTitle data-aime-component-name="CardTitle" data-aime-path-name="src/routes/page.tsx" data-aime-column="13" data-aime-line="1886" data-insp-path="src/routes/page.tsx:1886:13:CardTitle">Operasional Rider</CardTitle>
            <CardDescription
              className={
                reportMode ? 'font-black text-slate-800' : 'text-slate-500'
              }
             data-aime-component-name="CardDescription"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1887"  data-insp-path="src/routes/page.tsx:1887:13:CardDescription" >
              Performance Courier keeps the ongoing ranking table. POFD Checking
              reads from Raw Data, puts Date to the left of AWB, and keeps the
              same AWB on a different day as a separate row.
            </CardDescription>
          </CardHeader>
          <CardContent data-aime-component-name="CardContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="11" data-aime-line="1897" data-insp-path="src/routes/page.tsx:1897:11:CardContent">
            <Tabs
              value={driverDetailTab}
              onValueChange={value =>
                setDriverDetailTab(value as DriverDetailTab)
              }
              className="space-y-4"
             data-aime-component-name="Tabs"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="13"  data-aime-line="1898"  data-insp-path="src/routes/page.tsx:1898:13:Tabs" >
              <TabsList className="grid w-full grid-cols-2 rounded-2xl bg-sky-100/80 p-1 text-sky-900" data-aime-component-name="TabsList"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1905"  data-insp-path="src/routes/page.tsx:1905:15:TabsList" >
                <TabsTrigger
                  value="performance"
                  className="rounded-xl font-black"
                 data-aime-component-name="TabsTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1906"  data-insp-path="src/routes/page.tsx:1906:17:TabsTrigger" >
                  Performance Courier
                </TabsTrigger>
                <TabsTrigger
                  value="pofd-checking"
                  className="rounded-xl font-black"
                 data-aime-component-name="TabsTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1912"  data-insp-path="src/routes/page.tsx:1912:17:TabsTrigger" >
                  POFD Checking
                </TabsTrigger>
              </TabsList>
              <TabsContent value="performance" className="space-y-4" data-aime-component-name="TabsContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="1919"  data-insp-path="src/routes/page.tsx:1919:15:TabsContent" >
                <div className="w-full overflow-hidden rounded-2xl border border-sky-200" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="1920"  data-insp-path="src/routes/page.tsx:1920:17:div" >
                  <Table className="w-full table-fixed text-[10px] font-black text-slate-950 sm:text-[11px] xl:text-xs [&_td]:px-1.5 [&_td]:py-2 [&_td]:font-black [&_th]:h-auto [&_th]:px-1.5 [&_th]:py-2 [&_th]:font-black [&_th]:text-slate-900" data-aime-component-name="Table"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="1921"  data-insp-path="src/routes/page.tsx:1921:19:Table" >
                    <TableHeader data-aime-component-name="TableHeader" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="1922" data-insp-path="src/routes/page.tsx:1922:21:TableHeader">
                      <TableRow className="border-sky-200 bg-sky-50/90" data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="1923"  data-insp-path="src/routes/page.tsx:1923:23:TableRow" >
                        <TableHead className="w-[16%] whitespace-normal break-words leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1924"  data-insp-path="src/routes/page.tsx:1924:25:TableHead" >
                          Driver Name
                        </TableHead>
                        <TableHead className="w-[12%] whitespace-normal break-words leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1927"  data-insp-path="src/routes/page.tsx:1927:25:TableHead" >
                          Section
                        </TableHead>
                        <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1930"  data-insp-path="src/routes/page.tsx:1930:25:TableHead" >
                          {selectedPickupLabel}
                        </TableHead>

                        {show12PmColumns ? (
                          <>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1936"  data-insp-path="src/routes/page.tsx:1936:29:TableHead" >
                              Success Delivered &lt;12pm
                            </TableHead>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1939"  data-insp-path="src/routes/page.tsx:1939:29:TableHead" >
                              Presentase SD &lt;12PM 90%
                            </TableHead>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1942"  data-insp-path="src/routes/page.tsx:1942:29:TableHead" >
                              &lt;12PM Status
                            </TableHead>
                          </>
                        ) : null}

                        <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1948"  data-insp-path="src/routes/page.tsx:1948:25:TableHead" >
                          Failed To Deliver
                        </TableHead>
                        <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="1951"  data-insp-path="src/routes/page.tsx:1951:25:TableHead" >
                          Out For Delivery
                        </TableHead>

                        {showOverallColumns ? (
                          <>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1957"  data-insp-path="src/routes/page.tsx:1957:29:TableHead" >
                              Success Delivered Overall
                            </TableHead>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1960"  data-insp-path="src/routes/page.tsx:1960:29:TableHead" >
                              Presentase SD Overall 97%
                            </TableHead>
                            <TableHead className="whitespace-normal break-words text-right leading-tight font-black text-slate-800" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1963"  data-insp-path="src/routes/page.tsx:1963:29:TableHead" >
                              Overall Status
                            </TableHead>
                          </>
                        ) : null}
                      </TableRow>
                    </TableHeader>
                    <TableBody data-aime-component-name="TableBody" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="1970" data-insp-path="src/routes/page.tsx:1970:21:TableBody">
                      {visibleTableRows.map(row => {
                        const selectedPickup = getPickupValue(row, pickupView);
                        const pct12Value = get12PmPercentage(row);
                        const pct12Tier =
                          getTierFromSnapshotPercentage(pct12Value);
                        const pctOverallValue = getOverallPercentage(row);
                        const pctOverallTier = getOverallTier(row);

                        return (
                          <TableRow
                            key={`${row.section}-${row.driver}-${row.rowOrder}`}
                            className="border-sky-200"
                           data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="1980"  data-insp-path="src/routes/page.tsx:1980:27:TableRow" >
                            <TableCell
                              className="truncate font-black text-sky-950"
                              title={row.driver}
                             data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1984"  data-insp-path="src/routes/page.tsx:1984:29:TableCell" >
                              {row.driver}
                            </TableCell>
                            <TableCell className="break-words font-bold leading-tight text-slate-800" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1990"  data-insp-path="src/routes/page.tsx:1990:29:TableCell" >
                              {row.section}
                            </TableCell>
                            <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="1993"  data-insp-path="src/routes/page.tsx:1993:29:TableCell" >
                              {selectedPickup}
                            </TableCell>
                            {show12PmColumns ? (
                              <>
                                <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="1998"  data-insp-path="src/routes/page.tsx:1998:33:TableCell" >
                                  {row.sd12}
                                </TableCell>
                                <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2001"  data-insp-path="src/routes/page.tsx:2001:33:TableCell" >
                                  <Badge
                                    className={
                                      validPercentage(pct12Value) &&
                                      pct12Value >= 0.9
                                        ? 'bg-emerald-700 font-black text-white'
                                        : 'bg-red-900 font-black text-white'
                                    }
                                   data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2002"  data-insp-path="src/routes/page.tsx:2002:35:Badge" >
                                    {pct(pct12Value)}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2013"  data-insp-path="src/routes/page.tsx:2013:33:TableCell" >
                                  {pct12Tier ? (
                                    <Badge
                                      className={TIER_BADGE_CLASS[pct12Tier]}
                                     data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="37"  data-aime-line="2015"  data-insp-path="src/routes/page.tsx:2015:37:Badge" >
                                      {TIER_LABEL[pct12Tier]}
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-zinc-700 font-black text-white" data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="37"  data-aime-line="2021"  data-insp-path="src/routes/page.tsx:2021:37:Badge" >
                                      -
                                    </Badge>
                                  )}
                                </TableCell>
                              </>
                            ) : null}

                            <TableCell className="text-right font-black text-red-700" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2029"  data-insp-path="src/routes/page.tsx:2029:29:TableCell" >
                              {row.failed}
                            </TableCell>
                            <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2032"  data-insp-path="src/routes/page.tsx:2032:29:TableCell" >
                              {row.ofd}
                            </TableCell>

                            {showOverallColumns ? (
                              <>
                                <TableCell className="text-right font-black text-sky-950" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2038"  data-insp-path="src/routes/page.tsx:2038:33:TableCell" >
                                  {row.sdOverall}
                                </TableCell>
                                <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2041"  data-insp-path="src/routes/page.tsx:2041:33:TableCell" >
                                  <Badge
                                    className={
                                      pctOverallValue >= 0.97
                                        ? 'bg-emerald-700 font-black text-white'
                                        : 'bg-red-900 font-black text-white'
                                    }
                                   data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2042"  data-insp-path="src/routes/page.tsx:2042:35:Badge" >
                                    {pct(pctOverallValue)}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2052"  data-insp-path="src/routes/page.tsx:2052:33:TableCell" >
                                  <Badge
                                    className={TIER_BADGE_CLASS[pctOverallTier]}
                                   data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2053"  data-insp-path="src/routes/page.tsx:2053:35:Badge" >
                                    {TIER_LABEL[pctOverallTier]}
                                  </Badge>
                                </TableCell>
                              </>
                            ) : null}
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="2067"  data-insp-path="src/routes/page.tsx:2067:17:div" >
                  <p className="text-xs font-medium text-slate-500" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2068"  data-insp-path="src/routes/page.tsx:2068:19:p" >
                    Page {currentTablePage} of {totalTablePages} · 15 rows per
                    page
                  </p>
                  <div className="flex flex-wrap items-center gap-1" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2072"  data-insp-path="src/routes/page.tsx:2072:19:div" >
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={currentTablePage <= 1}
                      onClick={() =>
                        setTablePage(page => Math.max(1, page - 1))
                      }
                      className="h-8 border-sky-200 px-3 text-xs text-sky-800"
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2073"  data-insp-path="src/routes/page.tsx:2073:21:Button" >
                      ‹ Prev
                    </Button>
                    {Array.from(
                      { length: totalTablePages },
                      (_, index) => index + 1,
                    ).map(page => (
                      <Button
                        key={page}
                        type="button"
                        variant={
                          page === currentTablePage ? 'default' : 'outline'
                        }
                        size="sm"
                        onClick={() => setTablePage(page)}
                        className={`size-8 p-0 text-xs ${
                          page === currentTablePage
                            ? 'bg-sky-700 text-white hover:bg-sky-800'
                            : 'border-sky-200 text-sky-800'
                        }`}
                       data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2089"  data-insp-path="src/routes/page.tsx:2089:23:Button" >
                        {page}
                      </Button>
                    ))}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={currentTablePage >= totalTablePages}
                      onClick={() =>
                        setTablePage(page =>
                          Math.min(totalTablePages, page + 1),
                        )
                      }
                      className="h-8 border-sky-200 px-3 text-xs text-sky-800"
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2106"  data-insp-path="src/routes/page.tsx:2106:21:Button" >
                      Next ›
                    </Button>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="pofd-checking" className="space-y-4" data-aime-component-name="TabsContent"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="15"  data-aime-line="2123"  data-insp-path="src/routes/page.tsx:2123:15:TabsContent" >
                <div className="rounded-2xl border border-sky-200 bg-white/90 px-5 py-4" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="2124"  data-insp-path="src/routes/page.tsx:2124:17:div" >
                  <div className="flex flex-wrap items-start justify-between gap-3" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2125"  data-insp-path="src/routes/page.tsx:2125:19:div" >
                    <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="2126" data-insp-path="src/routes/page.tsx:2126:21:div">
                      <p className="text-2xl font-black text-slate-950" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2127"  data-insp-path="src/routes/page.tsx:2127:23:p" >
                        {filteredPofdRows.length} catatan • Action Required
                      </p>
                      <p className="mt-1 text-sm font-medium text-slate-600" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2130"  data-insp-path="src/routes/page.tsx:2130:23:p" >
                        Kasus belum sehat yang memerlukan tindak lanjut. Klik Edit untuk memperbarui catatan.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2134"  data-insp-path="src/routes/page.tsx:2134:21:div" >
                      <Badge className="bg-sky-800 font-black text-white" data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2135"  data-insp-path="src/routes/page.tsx:2135:23:Badge" >
                        {pofdReviewDate || 'Daily review'}
                      </Badge>
                      <Badge className={pofdLiveBadgeClass} data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2138"  data-insp-path="src/routes/page.tsx:2138:23:Badge" >
                        {pofdLiveBadgeLabel}
                      </Badge>
                    </div>
                  </div>
                  {pofdSyncMessage ? (
                    <output className="mt-3 block text-sm font-semibold text-emerald-700" data-aime-component-name="output"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2144"  data-insp-path="src/routes/page.tsx:2144:21:output" >
                      {pofdSyncMessage}
                    </output>
                  ) : null}
                </div>
                {editingPofdRow ? (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-sky-200 bg-sky-50 px-4 py-3" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2150"  data-insp-path="src/routes/page.tsx:2150:19:div" >
                    <div data-aime-component-name="div" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="2151" data-insp-path="src/routes/page.tsx:2151:21:div">
                      <p className="text-base font-black text-slate-950" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2152"  data-insp-path="src/routes/page.tsx:2152:23:p" >
                        Edit Action Required: {editingPofdRow.awb}
                      </p>
                      <p className="text-sm text-slate-600" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2155"  data-insp-path="src/routes/page.tsx:2155:23:p" >
                        Perubahan akan disimpan langsung ke Reason FTD setelah klik Simpan.
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="border-sky-200 bg-white font-black text-sky-900"
                      onClick={() => cancelPofdEditing(editingPofdRow.entryKey)}
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2159"  data-insp-path="src/routes/page.tsx:2159:21:Button" >
                      Tutup
                    </Button>
                  </div>
                ) : null}
                <div className="w-full overflow-x-auto rounded-2xl border border-sky-200" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="2170"  data-insp-path="src/routes/page.tsx:2170:17:div" >
                  <Table className="min-w-[1200px] table-fixed text-[10px] font-black text-slate-950 sm:text-[11px] xl:text-xs [&_td]:px-1.5 [&_td]:py-2 [&_td]:font-black [&_th]:h-auto [&_th]:px-1.5 [&_th]:py-2 [&_th]:font-black [&_th]:text-slate-900" data-aime-component-name="Table"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2171"  data-insp-path="src/routes/page.tsx:2171:19:Table" >
                    <TableHeader data-aime-component-name="TableHeader" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="2172" data-insp-path="src/routes/page.tsx:2172:21:TableHeader">
                      <TableRow className="border-sky-200 bg-sky-50/90" data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2173"  data-insp-path="src/routes/page.tsx:2173:23:TableRow" >
                        <TableHead className="w-[8%] whitespace-nowrap font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2174"  data-insp-path="src/routes/page.tsx:2174:25:TableHead" >
                          Tanggal
                        </TableHead>
                        <TableHead className="w-[12%] whitespace-nowrap font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2177"  data-insp-path="src/routes/page.tsx:2177:25:TableHead" >
                          Airwaybill
                        </TableHead>
                        <TableHead className="w-[13%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2180"  data-insp-path="src/routes/page.tsx:2180:25:TableHead" >
                          Driver Name
                        </TableHead>
                        <TableHead className="w-[18%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2183"  data-insp-path="src/routes/page.tsx:2183:25:TableHead" >
                          Cancellation Reason
                        </TableHead>
                        <TableHead className="w-[10%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2186"  data-insp-path="src/routes/page.tsx:2186:25:TableHead" >
                          Status
                        </TableHead>
                        <TableHead className="w-[15%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2189"  data-insp-path="src/routes/page.tsx:2189:25:TableHead" >
                          Alasan
                        </TableHead>
                        <TableHead className="w-[11%] whitespace-nowrap font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2192"  data-insp-path="src/routes/page.tsx:2192:25:TableHead" >
                          Input By
                        </TableHead>
                        <TableHead className="w-[7%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2195"  data-insp-path="src/routes/page.tsx:2195:25:TableHead" >
                          Klasifikasi
                        </TableHead>
                        <TableHead className="w-[6%] font-black text-slate-700" data-aime-component-name="TableHead"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2198"  data-insp-path="src/routes/page.tsx:2198:25:TableHead" >
                          Aksi
                        </TableHead>
                      </TableRow>
                      <TableRow className="hidden" data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2202"  data-insp-path="src/routes/page.tsx:2202:23:TableRow" >
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2203" data-insp-path="src/routes/page.tsx:2203:25:TableHead">
                          <Select
                            value={pofdFilterState.date || POFD_ALL_FILTER}
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                date: value === POFD_ALL_FILTER ? '' : value,
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2204"  data-insp-path="src/routes/page.tsx:2204:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2213"  data-insp-path="src/routes/page.tsx:2213:29:SelectTrigger" >
                              <SelectValue placeholder="All dates"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2214"  data-insp-path="src/routes/page.tsx:2214:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2216" data-insp-path="src/routes/page.tsx:2216:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2217"  data-insp-path="src/routes/page.tsx:2217:31:SelectItem" >
                                All
                              </SelectItem>
                              {pofdDateOptions.map(option => (
                                <SelectItem
                                  key={`date-filter-${option}`}
                                  value={option}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2221"  data-insp-path="src/routes/page.tsx:2221:33:SelectItem" >
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2231" data-insp-path="src/routes/page.tsx:2231:25:TableHead">
                          <Select
                            value={pofdFilterState.awb || POFD_ALL_FILTER}
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                awb: value === POFD_ALL_FILTER ? '' : value,
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2232"  data-insp-path="src/routes/page.tsx:2232:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2241"  data-insp-path="src/routes/page.tsx:2241:29:SelectTrigger" >
                              <SelectValue placeholder="All AWB"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2242"  data-insp-path="src/routes/page.tsx:2242:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2244" data-insp-path="src/routes/page.tsx:2244:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2245"  data-insp-path="src/routes/page.tsx:2245:31:SelectItem" >
                                All
                              </SelectItem>
                              {pofdAwbOptions.map(option => (
                                <SelectItem
                                  key={`awb-filter-${option}`}
                                  value={option}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2249"  data-insp-path="src/routes/page.tsx:2249:33:SelectItem" >
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2259" data-insp-path="src/routes/page.tsx:2259:25:TableHead">
                          <Select
                            value={
                              pofdFilterState.driverName || POFD_ALL_FILTER
                            }
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                driverName:
                                  value === POFD_ALL_FILTER ? '' : value,
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2260"  data-insp-path="src/routes/page.tsx:2260:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2272"  data-insp-path="src/routes/page.tsx:2272:29:SelectTrigger" >
                              <SelectValue placeholder="All drivers"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2273"  data-insp-path="src/routes/page.tsx:2273:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2275" data-insp-path="src/routes/page.tsx:2275:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2276"  data-insp-path="src/routes/page.tsx:2276:31:SelectItem" >
                                All
                              </SelectItem>
                              {pofdDriverOptions.map(option => (
                                <SelectItem
                                  key={`driver-filter-${option}`}
                                  value={option}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2280"  data-insp-path="src/routes/page.tsx:2280:33:SelectItem" >
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2290" data-insp-path="src/routes/page.tsx:2290:25:TableHead">
                          <Select
                            value={
                              pofdFilterState.cancellationReason ||
                              POFD_ALL_FILTER
                            }
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                cancellationReason:
                                  value === POFD_ALL_FILTER ? '' : value,
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2291"  data-insp-path="src/routes/page.tsx:2291:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2304"  data-insp-path="src/routes/page.tsx:2304:29:SelectTrigger" >
                              <SelectValue placeholder="All reasons"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2305"  data-insp-path="src/routes/page.tsx:2305:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2307" data-insp-path="src/routes/page.tsx:2307:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2308"  data-insp-path="src/routes/page.tsx:2308:31:SelectItem" >
                                All
                              </SelectItem>
                              {pofdCancellationOptions.map(option => (
                                <SelectItem
                                  key={`cancellation-filter-${option}`}
                                  value={option}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2312"  data-insp-path="src/routes/page.tsx:2312:33:SelectItem" >
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2322" data-insp-path="src/routes/page.tsx:2322:25:TableHead">
                          <Select
                            value={
                              pofdFilterState.result === 'all'
                                ? POFD_ALL_FILTER
                                : pofdFilterState.result || POFD_EMPTY_RESULT
                            }
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                result:
                                  value === POFD_ALL_FILTER
                                    ? 'all'
                                    : value === POFD_EMPTY_RESULT
                                      ? 'blank'
                                      : (value as PofdFilterState['result']),
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2323"  data-insp-path="src/routes/page.tsx:2323:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2341"  data-insp-path="src/routes/page.tsx:2341:29:SelectTrigger" >
                              <SelectValue placeholder="All"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2342"  data-insp-path="src/routes/page.tsx:2342:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2344" data-insp-path="src/routes/page.tsx:2344:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2345"  data-insp-path="src/routes/page.tsx:2345:31:SelectItem" >
                                All
                              </SelectItem>
                              <SelectItem value={POFD_EMPTY_RESULT} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2348"  data-insp-path="src/routes/page.tsx:2348:31:SelectItem" >
                                Blank
                              </SelectItem>
                              {POFD_RESULT_OPTIONS.filter(
                                option => option.value !== POFD_EMPTY_RESULT,
                              ).map(option => (
                                <SelectItem
                                  key={`filter-${option.value}`}
                                  value={option.value}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2354"  data-insp-path="src/routes/page.tsx:2354:33:SelectItem" >
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2364" data-insp-path="src/routes/page.tsx:2364:25:TableHead">
                          <Select
                            value={
                              pofdFilterState.reason === 'all'
                                ? POFD_ALL_FILTER
                                : pofdFilterState.reason || POFD_EMPTY_REASON
                            }
                            onValueChange={value =>
                              setPofdFilterState(prev => ({
                                ...prev,
                                reason:
                                  value === POFD_ALL_FILTER
                                    ? 'all'
                                    : value === POFD_EMPTY_REASON
                                      ? 'blank'
                                      : value,
                              }))
                            }
                           data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2365"  data-insp-path="src/routes/page.tsx:2365:27:Select" >
                            <SelectTrigger className="h-8 border-sky-200 bg-white text-[11px] font-black text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2383"  data-insp-path="src/routes/page.tsx:2383:29:SelectTrigger" >
                              <SelectValue placeholder="All"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2384"  data-insp-path="src/routes/page.tsx:2384:31:SelectValue" />
                            </SelectTrigger>
                            <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2386" data-insp-path="src/routes/page.tsx:2386:29:SelectContent">
                              <SelectItem value={POFD_ALL_FILTER} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2387"  data-insp-path="src/routes/page.tsx:2387:31:SelectItem" >
                                All
                              </SelectItem>
                              <SelectItem value={POFD_EMPTY_REASON} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2390"  data-insp-path="src/routes/page.tsx:2390:31:SelectItem" >
                                Blank
                              </SelectItem>
                              {pofdReasonOptions.map(option => (
                                <SelectItem
                                  key={`reason-filter-${option}`}
                                  value={option}
                                 data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2394"  data-insp-path="src/routes/page.tsx:2394:33:SelectItem" >
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableHead>
                        <TableHead  data-aime-component-name="TableHead" data-aime-path-name="src/routes/page.tsx" data-aime-column="25" data-aime-line="2404" data-insp-path="src/routes/page.tsx:2404:25:TableHead"/>
                      </TableRow>
                    </TableHeader>
                    <TableBody data-aime-component-name="TableBody" data-aime-path-name="src/routes/page.tsx" data-aime-column="21" data-aime-line="2407" data-insp-path="src/routes/page.tsx:2407:21:TableBody">
                      {visiblePofdRows.length > 0 ? (
                        visiblePofdRows.map(row => (
                          <TableRow
                            key={row.entryKey}
                            className="border-sky-200"
                           data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2410"  data-insp-path="src/routes/page.tsx:2410:27:TableRow" >
                            <TableCell className="text-slate-700" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2414"  data-insp-path="src/routes/page.tsx:2414:29:TableCell" >
                              {row.date}
                            </TableCell>
                            <TableCell className="break-all font-black text-sky-950" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2417"  data-insp-path="src/routes/page.tsx:2417:29:TableCell" >
                              {row.awb}
                            </TableCell>
                            <TableCell className="break-words leading-tight text-slate-800" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2420"  data-insp-path="src/routes/page.tsx:2420:29:TableCell" >
                              {row.driverName}
                            </TableCell>
                            <TableCell className="break-words leading-tight text-slate-600" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2423"  data-insp-path="src/routes/page.tsx:2423:29:TableCell" >
                              {row.cancellationReason || '—'}
                            </TableCell>
                            <TableCell data-aime-component-name="TableCell" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2426" data-insp-path="src/routes/page.tsx:2426:29:TableCell">
                              {pofdEditingKey === row.entryKey ? (
                                <Select
                                  value={row.draftReview.result || POFD_EMPTY_RESULT}
                                  onValueChange={value =>
                                    updatePofdResult(
                                      row,
                                      value === POFD_EMPTY_RESULT
                                        ? ''
                                        : (value as PofdResultValue),
                                    )
                                  }
                                  disabled={row.isSyncing}
                                 data-aime-component-name="Select"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2428"  data-insp-path="src/routes/page.tsx:2428:33:Select" >
                                  <SelectTrigger className="h-9 border-slate-200 bg-white text-xs font-semibold text-slate-800" data-aime-component-name="SelectTrigger"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2440"  data-insp-path="src/routes/page.tsx:2440:35:SelectTrigger" >
                                    <SelectValue placeholder="Pilih status"  data-aime-component-name="SelectValue"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="37"  data-aime-line="2441"  data-insp-path="src/routes/page.tsx:2441:37:SelectValue" />
                                  </SelectTrigger>
                                  <SelectContent data-aime-component-name="SelectContent" data-aime-path-name="src/routes/page.tsx" data-aime-column="35" data-aime-line="2443" data-insp-path="src/routes/page.tsx:2443:35:SelectContent">
                                    {POFD_RESULT_OPTIONS.map(option => (
                                      <SelectItem key={option.value} value={option.value} data-aime-component-name="SelectItem"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="39"  data-aime-line="2445"  data-insp-path="src/routes/page.tsx:2445:39:SelectItem" >
                                        {option.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              ) : (
                                <Badge
                                  variant="outline"
                                  className="border-slate-300 bg-white font-semibold text-slate-700"
                                 data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2452"  data-insp-path="src/routes/page.tsx:2452:33:Badge" >
                                  {row.draftReview.result
                                    ? row.draftReview.result === 'valid'
                                      ? 'Valid'
                                      : 'Invalid'
                                    : '—'}
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="min-w-56 text-slate-600" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2464"  data-insp-path="src/routes/page.tsx:2464:29:TableCell" >
                              {pofdEditingKey === row.entryKey ? (
                                <Input
                                  value={row.draftReview.reason}
                                  onChange={event =>
                                    updatePofdReason(row, event.target.value)
                                  }
                                  disabled={row.isSyncing}
                                  placeholder="Isi alasan"
                                  className="h-9 border-slate-200 bg-white text-xs font-semibold text-slate-800"
                                 data-aime-component-name="Input"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2466"  data-insp-path="src/routes/page.tsx:2466:33:Input" />
                              ) : (
                                row.draftReview.reason || '—'
                              )}
                            </TableCell>
                            <TableCell className="min-w-44 text-slate-600" data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="29"  data-aime-line="2479"  data-insp-path="src/routes/page.tsx:2479:29:TableCell" >
                              {pofdEditingKey === row.entryKey ? (
                                <Input
                                  value={row.draftReview.inputBy}
                                  onChange={event =>
                                    updatePofdInputBy(row, event.target.value)
                                  }
                                  disabled={row.isSyncing}
                                  placeholder="Nama penginput"
                                  className="h-9 border-slate-200 bg-white text-xs font-semibold text-slate-800"
                                 data-aime-component-name="Input"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2481"  data-insp-path="src/routes/page.tsx:2481:33:Input" />
                              ) : (
                                row.draftReview.inputBy || '—'
                              )}
                            </TableCell>
                            <TableCell data-aime-component-name="TableCell" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2494" data-insp-path="src/routes/page.tsx:2494:29:TableCell">
                              <Badge
                                variant="outline"
                                className={
                                  row.draftReview.result === 'valid'
                                    ? 'border-emerald-300 bg-emerald-50 font-black text-emerald-700'
                                    : row.draftReview.result === 'invalid'
                                      ? 'border-rose-300 bg-rose-50 font-black text-rose-700'
                                      : 'border-amber-300 bg-amber-50 font-black text-amber-700'
                                }
                               data-aime-component-name="Badge"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="31"  data-aime-line="2495"  data-insp-path="src/routes/page.tsx:2495:31:Badge" >
                                {row.draftReview.result === 'valid'
                                  ? 'SOLVED'
                                  : row.draftReview.result === 'invalid'
                                    ? 'ACTION'
                                    : 'OPEN'}
                              </Badge>
                            </TableCell>
                            <TableCell data-aime-component-name="TableCell" data-aime-path-name="src/routes/page.tsx" data-aime-column="29" data-aime-line="2512" data-insp-path="src/routes/page.tsx:2512:29:TableCell">
                              {pofdEditingKey === row.entryKey ? (
                                <div className="flex flex-wrap gap-2" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2514"  data-insp-path="src/routes/page.tsx:2514:33:div" >
                                  <Button
                                    type="button"
                                    size="sm"
                                    className="h-8 bg-sky-600 px-3 text-[11px] font-black text-white hover:bg-sky-700"
                                    disabled={!row.isDirty || row.isSyncing}
                                    onClick={() => void savePofdDraft(row)}
                                   data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2515"  data-insp-path="src/routes/page.tsx:2515:35:Button" >
                                    {row.isSyncing ? 'Menyimpan…' : 'Simpan'}
                                  </Button>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    className="h-8 border-sky-200 bg-white px-3 text-[11px] font-black text-sky-900"
                                    disabled={row.isSyncing}
                                    onClick={() => cancelPofdEditing(row.entryKey)}
                                   data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="35"  data-aime-line="2524"  data-insp-path="src/routes/page.tsx:2524:35:Button" >
                                    Batal
                                  </Button>
                                </div>
                              ) : (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  className="h-8 border-sky-200 bg-white px-3 text-[11px] font-black text-sky-900"
                                  onClick={() => startPofdEditing(row)}
                                 data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="33"  data-aime-line="2536"  data-insp-path="src/routes/page.tsx:2536:33:Button" >
                                  Edit
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow className="border-sky-200" data-aime-component-name="TableRow"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="25"  data-aime-line="2550"  data-insp-path="src/routes/page.tsx:2550:25:TableRow" >
                          <TableCell
                            colSpan={7}
                            className="py-8 text-center text-sm font-medium text-slate-500"
                           data-aime-component-name="TableCell"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="27"  data-aime-line="2551"  data-insp-path="src/routes/page.tsx:2551:27:TableCell" >
                            No failed-delivery rows match the current POFD
                            filters.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="17"  data-aime-line="2563"  data-insp-path="src/routes/page.tsx:2563:17:div" >
                  <p className="text-xs font-medium text-slate-500" data-aime-component-name="p"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2564"  data-insp-path="src/routes/page.tsx:2564:19:p" >
                    Page {currentPofdPage} of {totalPofdPages} · 12 rows per
                    page · {filteredPofdRows.length} filtered rows
                  </p>
                  <div className="flex flex-wrap items-center gap-1" data-aime-component-name="div"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="19"  data-aime-line="2568"  data-insp-path="src/routes/page.tsx:2568:19:div" >
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={currentPofdPage <= 1}
                      onClick={() => setPofdPage(page => Math.max(1, page - 1))}
                      className="h-8 border-sky-200 px-3 text-xs text-sky-800"
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2569"  data-insp-path="src/routes/page.tsx:2569:21:Button" >
                      ‹ Prev
                    </Button>
                    {Array.from(
                      { length: totalPofdPages },
                      (_, index) => index + 1,
                    ).map(page => (
                      <Button
                        key={`pofd-${page}`}
                        type="button"
                        variant={
                          page === currentPofdPage ? 'default' : 'outline'
                        }
                        size="sm"
                        onClick={() => setPofdPage(page)}
                        className={`size-8 p-0 text-xs ${
                          page === currentPofdPage
                            ? 'bg-sky-700 text-white hover:bg-sky-800'
                            : 'border-sky-200 text-sky-800'
                        }`}
                       data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="23"  data-aime-line="2583"  data-insp-path="src/routes/page.tsx:2583:23:Button" >
                        {page}
                      </Button>
                    ))}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={currentPofdPage >= totalPofdPages}
                      onClick={() =>
                        setPofdPage(page => Math.min(totalPofdPages, page + 1))
                      }
                      className="h-8 border-sky-200 px-3 text-xs text-sky-800"
                     data-aime-component-name="Button"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="21"  data-aime-line="2600"  data-insp-path="src/routes/page.tsx:2600:21:Button" >
                      Next ›
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <footer className="pb-2 text-center text-sm font-semibold text-[#1B1A1B]" data-aime-component-name="footer"  data-aime-path-name="src/routes/page.tsx"  data-aime-column="9"  data-aime-line="2619"  data-insp-path="src/routes/page.tsx:2619:9:footer" >
          Operational dashboard · Snapshot values displayed faithfully ·
          &lt;12PM Status uses target 90%. Overall Status: Finished! (100.0% OR
          OFD=0 with FTD&gt;0), All Nice (90.0%–99.9%), Decent (70.0%–89.9%),
          Far from done (&lt;70.0%).
        </footer>
      </div>
    </main>
  );
}

export default function Page() {
  return <Dashboard />;
}
